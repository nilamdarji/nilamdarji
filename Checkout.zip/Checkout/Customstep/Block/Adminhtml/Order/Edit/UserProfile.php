<?php
namespace Checkout\Customstep\Block\Adminhtml\Order\Edit;

class UserProfile extends \Magento\Backend\Block\Template
{

    /**
     * Session quote
     *
     * @var \Magento\Backend\Model\Session\Quote
     */
    protected $_sessionQuote;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Backend\Model\Session\Quote $sessionQuote
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Backend\Model\Session\Quote $sessionQuote,
        array $data = []
    ) {
        $this->_sessionQuote = $sessionQuote;
        parent::__construct($context, $data);
    }

    public function getOrder()
    {
        return $this->_sessionQuote->getOrder();
    }

    public function getTitle()
    {
        return "User Profile";
    }
}
