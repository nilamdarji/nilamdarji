<?php
namespace Checkout\Customstep\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetupFactory;

class InstallData implements InstallDataInterface
{

    private $customerSetupFactory;

    /**
     * Constructor
     *
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
        CustomerSetupFactory $customerSetupFactory
    ) {
        $this->customerSetupFactory = $customerSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'first_name',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'First Name'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'last_name',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Last Name'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'date_of_birth',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'comment' => 'Date of Birth'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'email',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Email'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'favorite_color',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Favorite Color'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('quote'),
                'comment',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Comment'
                ]
            );


            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'first_name',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'First Name'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'last_name',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Last Name'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'date_of_birth',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                    'comment' => 'Date of Birth'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'email',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Email'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'favorite_color',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Favorite Color'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order'),
                'comment',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'comment' => 'Comment'
                ]
            );
        }
    }
}
