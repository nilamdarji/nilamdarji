    define(
    [
        'ko',
        'jquery',
        'uiComponent',
        'underscore',
        'Magento_Checkout/js/model/step-navigator',
        'mage/url',
        'Magento_Ui/js/lib/validation/utils',
        'Magento_Ui/js/lib/validation/validator',
        'Magento_Ui/js/form/form',
        'jquery/ui', 
        'jquery/validate', 
        'mage/translate'
    ],
    function (
        ko,
        $,
        Component,
        _,
        stepNavigator,
        url,
        utils,
        validator
    ) {

        'use strict';
        return Component.extend({
            defaults: {
                template: 'Checkout_Customstep/checkout/mystep'
            },

            //add here your logic to display step,
            isVisible: ko.observable(false),

            initialize: function () {
                this._super();
                // register your step
                stepNavigator.registerStep(
                    //step code will be used as step content id in the component template
                    'custom-form',
                    //step alias                    
                    'custom-form',
                    //step title value
                    'Custom Form',
                    //observable property with logic when display step or hide step
                    this.isVisible,

                    _.bind(this.navigate, this),

                    /**
                        * sort order value
                        * 'sort order value' < 10: step displays before shipping step;
                        * 10 < 'sort order value' < 20 : step displays between shipping and payment step
                        * 'sort order value' > 20 : step displays after payment step
                    */
                    1
                );

              

                return this;
            },

            /**
             * The navigate() method is responsible for navigation between checkout step
             * during checkout. You can add custom logic, for example some conditions
             * for switching to your custom step
             */
            navigate: function () {
                var self = this;
                //getPaymentInformation().done(function () {
                    self.isVisible(true);
               // });

            },
               
            /**
             * Form submit handler
             *
             * This method can have any name.
             */
            onSubmit: function() {
                // trigger form validation
                this.source.set('params.invalid', false);
                this.source.trigger('customCheckoutForm.data.validate');

                // verify that form data is valid
                if (!this.source.get('params.invalid')) {
                    // data is retrieved from data provider by value of the customScope property
                    var formData = this.source.get('customCheckoutForm');
                    // do something with form data
                    console.dir(formData);
                }
            },

            navigateToNextStep: function () {
                var isValid = true;
                if($("input[name=first_name]").val() == "") {
                    isValid = false;
                    $("input[name=first_name]").focus();
                }

                if($("input[name=last_name]").val() == "") {
                    isValid = false;
                    $("input[name=last_name]").focus();
                }

                if($("input[name=date_of_birth]").val() == "") {
                    isValid = false;
                    $("input[name=date_of_birth]").focus();
                }

                if($("input[name=email_id]").val() == "") {
                    isValid = false;
                    $("input[name=email_id]").focus();
                } else {
                    var email   = $("input[name=email_id]").val();
                    var regex = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
                    if(!regex.test(email)) {
                       $("input[name=email_id]").focus();
                    }
                }

                if($("input[name=favorite_color]").val() == "") {
                    isValid = false;
                    $("input[name=favorite_color]").focus();
                }

                if($("input[name=comment]").val() == "") {
                    isValid = false;
                    $("input[name=comment]").focus();
                }

                if(isValid) {
                    var linkUrls  = url.build('Customstep/checkout/SaveInQuote');
                    $.ajax({
                        showLoader: true,
                        url: linkUrls,
                        data: $('#custom-checkout-form').serialize(),
                        type: "POST",
                        dataType: 'json'
                    }).done(function (data) {
                        if (data.suceess) {
                            stepNavigator.next();
                        }
                    });
                }
            }
        });
    }
);
