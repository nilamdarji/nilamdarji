<?php
namespace Checkout\Customstep\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
 
class PlaceOrder implements ObserverInterface
{

    public function execute(Observer $observer)
    {
        /* @var $order \Magento\Sales\Model\Order */
        $order = $observer->getEvent()->getOrder();
        
        /** @var $quote \Magento\Quote\Model\Quote $quote */
        $quote = $observer->getEvent()->getQuote();

        $order->setFirstName($quote->getFirstName());
        $order->setLastName($quote->getLastName());
        $order->setDateOfBirth($quote->getDateOfBirth());
        $order->setEmail($quote->getEmail());
        $order->setFavoriteColor($quote->getFavoriteColor());
        $order->setComment($quote->getComment());

        $order->save();
    }
}
