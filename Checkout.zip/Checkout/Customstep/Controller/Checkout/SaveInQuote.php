<?php

namespace Checkout\Customstep\Controller\Checkout;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\Action\Action;
use Magento\Checkout\Model\Session;
use Magento\Quote\Model\QuoteRepository;

class SaveInQuote extends Action
{
    protected $resultJsonFactory;
    protected $layoutFactory;
    protected $cart;

    public function __construct(
        Context $context,
        Session $checkoutSession,
        QuoteRepository $quoteRepository,
        JsonFactory $resultJsonFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->checkoutSession   = $checkoutSession;
        $this->quoteRepository   = $quoteRepository;

        parent::__construct($context);
    }

    public function execute()
    {
        $result = [];
        try {
            $resultJson = $this->resultJsonFactory->create();
            $quote = $this->getQuote();
            
            if (!$quote || !$quote->getId()) {
                $resultJson->setData(["message" =>__("Quote not found."), "suceess" => false]);
                return $resultJson;
            }

            $quote->setFirstName($this->getRequest()->getParam('first_name'));
            $quote->setLastName($this->getRequest()->getParam('last_name'));
            $quote->setDateOfBirth($this->getRequest()->getParam('date_of_birth'));
            $quote->setEmail($this->getRequest()->getParam('email_id'));
            $quote->setFavoriteColor($this->getRequest()->getParam('favorite_color'));
            $quote->setComment($this->getRequest()->getParam('comment'));
            $quote->save();

            $result = ["message" =>__("Custom Form data saved successfully."), "suceess" => true];
        } catch (Exception $e) {
            $result = ["message" =>__($e->getMessage()), "suceess" => false];
        }
        
        $resultJson->setData($result);
        return $resultJson;
    }

    public function getQuote()
    {
        $quoteId = $this->checkoutSession->getQuoteId();
        return $this->quoteRepository->get($quoteId);
    }
}
