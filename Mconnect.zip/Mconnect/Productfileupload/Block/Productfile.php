<?php

namespace Mconnect\Productfileupload\Block;

use Magento\Framework\View\Element\Template;
use Magento\Catalog\Model\Product as ModelProduct;

class Productfile extends Template
{
	/**
	* @var \Magento\Framework\App\Config\ScopeConfigInterface
	*/
	protected $_scopeConfigObject;
	
	protected $_jsonEncoder;
	
	protected $_storeManager;
	 
    protected $_urlInterface;
		
	/**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;
	
	/**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
	
	
    public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfilestore\CollectionFactory $pfsCollection,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfile\CollectionFactory $pfCollection,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct\CollectionFactory $pfpCollection,
		//\Magento\Store\Model\StoreManagerInterface $storeManager,
       // \Magento\Framework\UrlInterface $urlInterface,
		\Magento\Framework\ObjectManagerInterface $objectManager,
		\Magento\Framework\App\ResourceConnection $resource,
		array $data = []
		){
		parent::__construct($context, $data);		
		$this->_pfsCollection = $pfsCollection;
		$this->_pfCollection = $pfCollection;
		$this->_pfpCollection = $pfpCollection;
		$this->_storeManager = $context->getStoreManager();
	    $this->_urlInterface = $context->getUrlBuilder();	  
		$this->_objectManager = $objectManager;
		$this->_resource = $resource;
    }	
	
	public function getProductFilesCollection()
    {
		
		$productCollection = $this->_objectManager->get('Magento\Framework\Registry')->registry('current_product');
		$product_id = $productCollection->getId();
		
		$pfpCollection = $this->_pfpCollection->create();		
		$pfpCollection->addFieldToFilter('product_id',$product_id);			
		$availableFileId = $pfpCollection->getColumnValues('productfile_id');
		
		$pfCollection = $this->_pfCollection->create();
		
		//$pfCollection->addFieldToFilter('status', '1');
		
		$store_id=$this->_storeManager->getStore()->getId();
		
		$mconnect_productfile_store = $this->_resource->getTableName('mconnect_productfile_store');
		 
		$pfCollection->getSelect()->joinLeft( array($mconnect_productfile_store=> $mconnect_productfile_store), "$mconnect_productfile_store.productfile_id = `main_table`.entity_id AND `main_table`.status = 1", array("$mconnect_productfile_store.store_id as store_id"));		
		
		$pfCollection->addFieldToFilter('entity_id', array('in' => $availableFileId));		
		
		$pfCollection->getSelect()->where("store_id = $store_id OR store_id = 0")->group('entity_id');
				
			
		return $pfCollection;		
		
    }	
	
	public function getMediaUrl()
	{
		
		return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
	
	public function getAjaxUrl()
    {
        return $this->getUrl("customer/ajax/login");
    }
	
	public function getHomeUrl()
    {
        return $this->getUrl();
    }

}