<?php
namespace Mconnect\Productfileupload\Block\Adminhtml\Productfile\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;

class Stores extends Generic implements TabInterface
{

	/**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
		\Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }
	
	
	/**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm(){
		
		/** @var $model \Mconnect\Faq\Model\Faq */
		
		
        $model = $this->_coreRegistry->registry('productfile');
		
		if ($this->_isAllowedAction('Mconnect_Productfileupload::productfileupload_save')) {
            $isElementDisabled = false;
        } else {
            $isElementDisabled = true;
        }
		
		
 
        /** @var \Magento\Framework\Data\Form $form */
		
		 $form = $this->_formFactory->create();
		 $form->setHtmlIdPrefix('productfile_');
		 
		 
 
        $fieldset = $form->addFieldset('base_fieldset_store', ['legend' => __('Product File Upload Store')] );
		
		/*
		$field = $fieldset->addField(
            'store_id',
            'multiselect',
            [
				'name' => 'stores[]',
				'label' => __('Store View'),
				'title' => __('Store View'),
				'required' => true,
				'values' => $this->_systemStore->getStoreValuesForForm(false, true)
            ]
        );
        $renderer = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element'
            );
        $field->setRenderer($renderer);
		*/
		
		
		/**
         * Check is single store mode
         */
		 
        if (!$this->_storeManager->isSingleStoreMode()) {
			
            $field = $fieldset->addField(
                'store_id',
                'multiselect',
                [
                    'name' => 'stores[]',
                    'label' => __('Store View'),
                    'title' => __('Store View'),
                    'required' => true,
                    'values' => $this->_systemStore->getStoreValuesForForm(false, true)
                ]
            );
			
            $renderer = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element'
            );
			
            $field->setRenderer($renderer);
			
			
        } else {
            $fieldset->addField(
                'store_id',
                'hidden',
                ['name' => 'stores[]', 'value' => $this->_storeManager->getStore(true)->getId()]
            );
            $model->setStoreId($this->_storeManager->getStore(true)->getId());
        }
		
		
		
		
		if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }
		
				
		$form->setValues($model->getData());
        $this->setForm($form);
 
        return parent::_prepareForm();

	}
	
	/**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __("PFU's Store");
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __("PFU's Store");
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
	
	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

}	