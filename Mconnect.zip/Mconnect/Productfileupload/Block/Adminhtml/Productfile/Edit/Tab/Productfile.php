<?php
namespace Mconnect\Productfileupload\Block\Adminhtml\Productfile\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Cms\Model\Wysiwyg\Config;

class Productfile extends Generic implements TabInterface
{
	/**
	* @var \Magento\Cms\Model\Wysiwyg\Config
	*/
    protected $_wysiwygConfig;
 
 
   /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Config $wysiwygConfig
     * @param Status $faqStatus
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Config $wysiwygConfig,
        
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
       /** @var $model \Mconnect\Faq\Model\Faq */
        $model = $this->_coreRegistry->registry('productfile');
		
		if ($this->_isAllowedAction('Mconnect_Productfileupload::save')) {
            $isElementDisabled = false;
        } else {
            $isElementDisabled = true;
        }
 
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('productfile_');
 
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Product File Upload Information')] );
		
	
		if ($model->getId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'id']);
			
	$fieldset->addType('file', '\Mconnect\Productfileupload\Block\Adminhtml\Productfile\Renderer\Files');
			
        }
		
	

        $fieldset->addField(
            'filename',
            'text',
            [
                'name'     => 'filename',
                'label'    => __('File Name'),
                'required' => true,
				'disabled' => $isElementDisabled,
				'note'	=> 'Name to be displayed on product page',
				'class' => 'required-entry',
            ]
        );
        
		$fieldset->addField(
            'filepath',
            'file',
            [
                'name'     => 'filepath',
                'label'    => __('Select File'),
				'required' => true,
				
               
            ]
        );
		
		$fieldset->addField(
			'status', 
			'select', 
				array(
					'label' => 'Status',
					'name'  => 'status',
					'values'=> array(
									array(
										'value' => 1,
										'label' => 'Enabled',
									),
									array(
										'value' => 0,
										'label' => 'Disabled',
									),
								),
					));
		
		
		/*
		$fieldset->addField('filepath', 'file', array(
            'label' => Mage::helper('mconnect_productfileupload')->__('Select File'),
            'name'  => 'filepath',
            'note'	=> $this->__('Allowed types : '.Mage::getStoreConfig('mconnect_productfileupload/general/fileextensions',Mage::app()->getStore())),
        ));
		*/
        
		if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);
 
        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __("PFU's Info");
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __("PFU's Info");
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
	
	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
	
}