<?php
/**
 * M-Connect Solutions.
 *
 * NOTICE OF LICENSE
 *
 * @category   Catalog
 * @package   Mconnect_Faq
 * @author      M-Connect Solutions (http://www.magentoconnect.us)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Mconnect\Productfileupload\Block\Adminhtml\Productfile\Edit;

use Magento\Backend\Block\Widget\Tabs as WidgetTabs;

class Tabs extends WidgetTabs
{
	/**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('pfu_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('PFU Information'));
    }

    /**
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'pfu_info',
            [
                'label' => __('General Information'),
                'title' => __('General Information'),
                'content' => $this->getLayout()->createBlock('Mconnect\Productfileupload\Block\Adminhtml\Productfile\Edit\Tab\Productfile')->toHtml(),
                'active' => true
            ]
        );
		
		if (!$this->_storeManager->isSingleStoreMode()) {
		$this->addTab(
            'pfu_store',
            [
                'label' => __('Store views'),
                'title' => __('Store views'),
                'content' => $this->getLayout()->createBlock('Mconnect\Productfileupload\Block\Adminhtml\Productfile\Edit\Tab\Stores')->toHtml(),
               // 'active' => true
            ]
        );
		
		}
		
		$this->addTab(
            'pfu_products',
            [
                'label' => __('Products'),
                'title' => __('Products'),
                'url' => $this->getUrl('productfileupload/*/products', ['_current' => true]),
                'class' => 'ajax'
            ]
        );
		
        return parent::_beforeToHtml();
    }
}