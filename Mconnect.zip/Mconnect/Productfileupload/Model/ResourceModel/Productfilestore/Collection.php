<?php
namespace Mconnect\Productfileupload\Model\ResourceModel\Productfilestore;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{ 
	protected $_idFieldName = 'productfile_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Productfileupload\Model\Productfilestore', 'Mconnect\Productfileupload\Model\ResourceModel\Productfilestore');		
    } 
	
}