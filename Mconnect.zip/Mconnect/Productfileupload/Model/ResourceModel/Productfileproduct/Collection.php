<?php
namespace Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{ 
	protected $_idFieldName = 'rel_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Productfileupload\Model\Productfileproduct', 'Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct');		
    } 
	
}