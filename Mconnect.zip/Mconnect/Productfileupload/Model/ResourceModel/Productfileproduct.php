<?php
namespace Mconnect\Productfileupload\Model\ResourceModel;
 
class Productfileproduct extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
	const TBL_M_PF_PRODUCT = 'mconnect_productfile_product';
	
	protected $_storeManager;
	 
	protected $_store = null;
	
	public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
		$connectionName = null
    ) {  
		parent::__construct($context, $connectionName);
        $this->_storeManager = $storeManager;
    }
	 
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {       
        $this->_init('mconnect_productfile_product', 'rel_id');
    }
	
	

	
}