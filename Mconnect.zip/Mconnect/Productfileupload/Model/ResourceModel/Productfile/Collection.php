<?php
namespace Mconnect\Productfileupload\Model\ResourceModel\Productfile;

use Mconnect\Productfileupload\Model\ResourceModel\AbstractCollection;
 
class Collection extends AbstractCollection
{ 
	protected $_idFieldName = 'entity_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Productfileupload\Model\Productfile', 'Mconnect\Productfileupload\Model\ResourceModel\Productfile');	
		$this->_map['fields']['store'] = 'store_table.store_id'; 
    } 
	
	public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }
	
	/*
	protected function _afterLoad()
    {		
        $this->performAfterLoad('mconnect_productfile_store', 'productfile_id');
		
        return parent::_afterLoad();
    }*/
	
	public function addStoreFilter($store, $withAdmin = true)
    {
		$this->performAddStoreFilter($store, $withAdmin);
	
        return $this;
    }
	/*
	protected function _renderFiltersBefore()
    {
        $this->joinStoreRelationTable('mconnect_productfile_store', 'productfile_id');
		parent::_renderFiltersBefore();
    }*/
	
}