<?php
namespace Mconnect\Productfileupload\Model\ResourceModel;
 
class Productfile extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
	protected $_storeManager;
	 
	protected $_store = null;
	
	public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
		$connectionName = null
    ) {  
		parent::__construct($context, $connectionName);
        $this->_storeManager = $storeManager;
    }
	 
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {       
        $this->_init('mconnect_productfile', 'entity_id');
    }
	
	
	
	protected function _beforeDelete(\Magento\Framework\Model\AbstractModel $object)
    {
        $condition = ['productfile_id = ?' => (int)$object->getId()];

        $this->getConnection()->delete($this->getTable('mconnect_productfile_store'), $condition);

        return parent::_beforeDelete($object);
    }
	
    /**
     * Perform operations after object save
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {
        $oldStores = $this->lookupStoreIds($object->getEntityId());
        $newStores = (array)$object->getStores();

        $table = $this->getTable('mconnect_productfile_store');
        $insert = array_diff($newStores, $oldStores);
        $delete = array_diff($oldStores, $newStores);
		
        if ($delete) {
            $where = ['productfile_id = ?' => (int)$object->getEntityId(), 'store_id IN (?)' => $delete];
            $this->getConnection()->delete($table, $where);
        }

        if ($insert) {
            $data = [];
	
            foreach ($insert as $storeId) {
                $data[] = ['productfile_id' => (int)$object->getEntityId(), 'store_id' => (int)$storeId];
            }

            $this->getConnection()->insertMultiple($table, $data);
        }

        return parent::_afterSave($object);
    }
  

    /**
     * Perform operations after object load
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _afterLoad(\Magento\Framework\Model\AbstractModel $object)
    { 
		
		
        if ($object->getEntityId()) {
            $stores = $this->lookupStoreIds($object->getEntityId());		
			
            $object->setData('store_id', $stores);
            $object->setData('stores', $stores);
        }		
        return parent::_afterLoad($object);
    }
	
	
	public function load(\Magento\Framework\Model\AbstractModel $object, $value, $field = null)
    {
        if (!is_numeric($value) && $field === null) {
            $field = 'productfile_id';
        }

        return parent::load($object, $value, $field);
    }
	

    /**
     * Retrieve select object for load object data
     *
     * @param string $field
     * @param mixed $value
     */
    protected function _getLoadSelect($field, $value, $object)
    {
        $select = parent::_getLoadSelect($field, $value, $object);
		
       if ($object->getStoreId()) {
           $storeIds = [\Magento\Store\Model\Store::DEFAULT_STORE_ID, (int)$object->getStoreId()];

            $select->join(
                ['cbs' => $this->getTable('mconnect_productfile_store')],
                $this->getMainTable() . '.productfile_id = cbs.productfile_id',
                ['store_id']
            )->where(
                'cbs.store_id in (?)',
                $storeIds
            )->order(
                'store_id DESC'
            )->limit(
                1
            );
       }

        return $select;
    }

    /**
     * Check for unique to selected store(s).
     *
     */
    public function getIsUniqueBlockToStores(\Magento\Framework\Model\AbstractModel $object)
    {
        if ($this->_storeManager->hasSingleStore()) {
            $stores = [\Magento\Store\Model\Store::DEFAULT_STORE_ID];
        } else {
            $stores = (array)$object->getData('stores');
        }

        $select = $this->getConnection()->select()->from(
            ['cb' => $this->getMainTable()]
        )->join(
            ['cbs' => $this->getTable('mconnect_productfile_store')],
            'cb.productfile_id = cbs.productfile_id',
            []
        )->where(
            'cb.productfile_id = ?',
            $object->getData('productfile_id')
        )->where(
            'cbs.store_id IN (?)',
            $stores
        );

        if ($object->getEntityId()) {
            $select->where('cb.productfile_id <> ?', $object->getEntityId());
        }

        if ($this->getConnection()->fetchRow($select)) {
            return false;
        }

        return true;
    }
	
	/**
     * Check for unique page promopoup for selected store(s).
     *
     */
    public function getIsUniquePageToStores(\Magento\Framework\Model\AbstractModel $object)
    {
        if ($this->_storeManager->hasSingleStore()) {
            $stores = [\Magento\Store\Model\Store::DEFAULT_STORE_ID];
        } else {
            $stores = (array)$object->getData('stores');
        }

        $select = $this->getConnection()->select()->from(
            ['cb' => $this->getMainTable()]
        )->join(
            ['cbs' => $this->getTable('mconnect_productfile_store')],
            'cb.productfile_id = cbs.productfile_id',
            []
        )->where(
            'cb.on_page = ?',
            $object->getData('on_page')
        )->where(
            'cbs.store_id IN (?,0)',
            $stores
        );
		
        if ($object->getEntityId()) {
            $select->where('cb.productfile_id <> ?', $object->getEntityId());
        }

        if ($this->getConnection()->fetchRow($select)) {
            return false;
        }

        return true;
    }
	
	
	public function setStore($store)
    {
        $this->_store = $store;
        return $this;
    }

    /**
     * Retrieve store model
     *
     * @return \Magento\Store\Model\Store
     */
    public function getStore()
    {
        return $this->_storeManager->getStore($this->_store);
    }

    /**
     * Get store ids to which specified item is assigned
     *
     * @param int $id
     * @return array
     */
    public function lookupStoreIds($id)
    {
        $connection = $this->getConnection();

        $select = $connection->select()->from(
            $this->getTable('mconnect_productfile_store'),
            'store_id'
        )->where(
            'productfile_id = :productfile_id'
        );

        $binds = [':productfile_id' => (int)$id];

        return $connection->fetchCol($select, $binds);
    }
	
	
}