<?php
/**
 * Copyright � 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mconnect\Productfileupload\Ui\DataProvider\Product\Modifier;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\Data\ProductLinkInterface;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Phrase;
use Magento\Framework\UrlInterface;
use Magento\Ui\Component\DynamicRows;
use Magento\Ui\Component\Form\Element\DataType\Number;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Ui\Component\Form\Element\DataType\Media;
use Magento\Ui\Component\Form\Element\Input;
use Magento\Ui\Component\Form\Element\MultiSelect;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Form\Fieldset;
use Magento\Ui\Component\Modal;
use Magento\Ui\Component\Container;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Helper\Image as ImageHelper;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;



class Productupload extends AbstractModifier 
{
    const DATA_SCOPE = '';
    const DATA_SCOPE_PFU = 'productfileupload';
    const GROUP_PFUTAB = 'productfileupload';
	
	const DATA_SCOPE_PFU_NEXT = 'productfileuploadnext';
    const GROUP_PFUTAB_NEXT = 'productfileuploadnext';
	
	const CONTAINER_HEADER_NAME = 'custom_fieldset_content_header';

    /**
     * @var string
     */
    private static $previousGroup = 'search-engine-optimization';

    /**
     * @var int
     */
    private static $sortOrder = 90;

    /**
     * @var LocatorInterface
     */
    protected $locator;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var ProductLinkRepositoryInterface
     */
    protected $productLinkRepository;

    /**
     * @var ImageHelper
     */
    protected $imageHelper;
	/**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var Status
     */
    protected $status;

    /**
     * @var AttributeSetRepositoryInterface
     */
    protected $attributeSetRepository;

    /**
     * @var string
     */
    protected $scopeName;

    /**
     * @var string
     */
    protected $scopePrefix;

	private $faqFactory;
	
	private $faqcollection;
	
	private $pfcollection;
	
	protected $_pfCollection ;
	
    /**
     * @param LocatorInterface $locator
     * @param UrlInterface $urlBuilder
     * @param ProductLinkRepositoryInterface $productLinkRepository
     * @param ProductRepositoryInterface $productRepository
     * @param ImageHelper $imageHelper
     * @param Status $status
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param string $scopeName
     * @param string $scopePrefix
     */
    public function __construct(
		LocatorInterface $locator,
        UrlInterface $urlBuilder,
        ImageHelper $imageHelper,
		StoreManagerInterface $storeManager,
        Status $status,
        AttributeSetRepositoryInterface $attributeSetRepository,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfile\CollectionFactory $pfCollection,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct\CollectionFactory $pfpCollection,
        $scopeName = '',
        $scopePrefix = ''
    ) { 
        $this->locator = $locator;
        $this->urlBuilder = $urlBuilder;
        $this->imageHelper = $imageHelper;
		$this->storeManager = $storeManager;
        $this->status = $status;
        $this->attributeSetRepository = $attributeSetRepository;
		$this->_pfCollection = $pfCollection;
		$this->_pfpCollection = $pfpCollection;
        $this->scopeName = $scopeName;
        $this->scopePrefix = $scopePrefix;		
    }

    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    { 
	
        $meta = array_replace_recursive(
            $meta,
            [
                static::GROUP_PFUTAB => [
                    'children' => [
                        $this->scopePrefix . static::DATA_SCOPE_PFU => $this->getPfuFieldset(),
                    ],
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'label' => __('Product File Upload'),
                                'collapsible' => true,
                                'componentType' => Fieldset::NAME,
                                'dataScope' => static::DATA_SCOPE,
                                'sortOrder' => 200,
                                   
                            ],
                        ],

                    ],
                ],
            ]
        );

        return $meta;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyData(array $data)
    {
		$product = $this->locator->getProduct();
		$productId = $product->getId();

        if (!$productId) {
            return $data;
        }


		$pfpCollection = $this->_pfpCollection->create();
		$pfpCollection->addFieldToFilter('product_id',$productId);
		$availablePFU = $pfpCollection->getColumnValues('productfile_id');
		
		$pfCollection = $this->_pfCollection->create();		
		
		 foreach ($this->getDataScopes() as $dataScope) { 
            $data[$productId]['links'][$dataScope] = [];
			
            foreach ($pfCollection as $linkItem) {
               if(in_array($linkItem->getId(),$availablePFU)){
                  $data[$productId]['links'][$dataScope][] = $this->fillData($linkItem);
				}
            }
			
        }
		
		$data[$productId][self::DATA_SOURCE_DEFAULT]['current_product_id'] = $productId;
        $data[$productId][self::DATA_SOURCE_DEFAULT]['current_store_id'] = $this->locator->getStore()->getId();
		
        return $data;
    }

    
    /**
     * Prepare data column
     *
     * @param ProductInterface $linkedProduct
     * @param ProductLinkInterface $linkItem
     * @return array
     */
    protected function fillData($linkItem)
    {
		return [
            'id' => $linkItem->getEntityId(),            
            'filename' => $linkItem->getFilename(),            
            'filepath' => $linkItem->getFilepath(),           
        ];
    }

    /**
     * Retrieve all data scopes
     *
     * @return array
     */
    protected function getDataScopes()
    {
        return [
            static::DATA_SCOPE_PFU,
        ];
    }

    /**
     * Prepares config for the Related products fieldset
     *
     * @return array
     */
    protected function getPfuFieldset()
    {
		
        $content = __(
            'Add File in this Product ? Click on "Add File" button, and Select Product file Upload.'
        );

        return [
            'children' => [
                'button_set' => $this->getButtonSet(
                    $content,
                    __('Add File'),
                    $this->scopePrefix . static::DATA_SCOPE_PFU
                ),
                'modal' => $this->getGenericModal(
                    __('Add File'),
                    $this->scopePrefix . static::DATA_SCOPE_PFU
                ),				
				
                static::DATA_SCOPE_PFU => $this->getGrid($this->scopePrefix . static::DATA_SCOPE_PFU),
				
            ],
            'arguments' => [
                'data' => [
                    'config' => [
                        'additionalClasses' => 'admin__fieldset-section',
                        'label' => __('Products File Upload'),
                        'collapsible' => false,
                        'componentType' => Fieldset::NAME,
                        'dataScope' => '',
                        'sortOrder' => 10,
                    ],
                ],
            ]
        ];
    }
	
	
	/**
     * Get config for header container
     *
     * @param int $sortOrder
     * @return array
     */
    protected function getProductFileUploadForm($sortOrder)
    {	
		
		$content = __(
            'Add File in this Product ? Click on "Add File" button, and Select Product file Upload.'
        );

        return [
            'children' => [
                'button_set_next' => $this->getButtonSetNext(
                    $content,
                    __('Add File Next'),
                    $this->scopePrefix . static::DATA_SCOPE_PFU_NEXT
                ),
				
                'modalnext' => $this->getGenericModalNext(
                    __('Add File Next'),
                    $this->scopePrefix . static::DATA_SCOPE_PFU_NEXT
                ),				
             
				
            ],
            'arguments' => [
                'data' => [
                    'config' => [
                        'additionalClasses' => 'admin__fieldset-section',
                        'label' => __('Products File Upload'),
                        'collapsible' => false,
                        'componentType' => Fieldset::NAME,
                        'dataScope' => '',
                        'sortOrder' => 10,
                    ],
                ],
            ]
        ];

	
		
		
    }
	
	
	
	protected function getButtonSetNext(Phrase $content, Phrase $buttonTitle, $scope)
    {
        //$modalTarget = $this->scopeName . '.' . static::GROUP_PFUTAB_NEXT . '.' . $scope . '.modalnext';
	$modalTarget ='product_form.product_form.productfileuploadnext.productfileuploadnext.modalnext';
	$buttonTitle='Add File Next 2';
	$scope='productfileuploadnext';
	

        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'formElement' => 'container',
                        'componentType' => 'container',
                        'label' => false,
                        'template' => 'ui/form/components/complex',
                    ],
                ],
            ],
            'children' => [
                'button_' . $scope => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'formElement' => 'container',
                                'componentType' => 'container',
                                'component' => 'Magento_Ui/js/form/components/button',
                                'actions' => [
                                    [
                                        'targetName' => $modalTarget,
                                        'actionName' => 'toggleModal',
                                    ],
                                    [
                                        'targetName' => $modalTarget . '.' . $scope . '_index_grid',
                                        'actionName' => 'render',
                                    ]
                                ],
                                'title' => $buttonTitle,
                                'provider' => null,
                            ],
                        ],
                    ],

                ],
            ],
        ];
    }

	
	protected function getGenericModalNext(Phrase $title, $scope)
    {
        $listingTarget = $scope . '_index_grid';
		
		
        $modal = [
            'arguments' => [
                'data' => [
                    'config' => [
						
                        'componentType' => Modal::NAME,
                        'dataScope' => '',
                        'options' => [
                            'title' => $title,
                            'buttons' => [
                                [
                                    'text' => __('Cancel'),
									'class' => 'cancel-btn',
                                    'actions' => [
                                        'closeModal'
                                    ]
                                ],
                                [
                                    'text' => __('Add Selected File'),
                                    'class' => 'action-primary',
                                    'actions' => [
                                        [
                                            'targetName' => 'index = ' . $listingTarget,
                                            'actionName' => 'save'
                                        ],
                                        'closeModal'
                                    ]
                                ],
								
                            ],
                        ],						
						    
                    ],
                ],
            ],
            'children' => [
			//	static::CONTAINER_HEADER_NAME => $this->getProductFileUploadFormNext(10),
			//	static::CONTAINER_HEADER_NAME => $this->getProductFileUploadFormNext($listingTarget),
				
				$listingTarget => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'autoRender' => false,
                                'componentType' => 'insertListing',
                                'dataScope' => $listingTarget,
                                'externalProvider' => $listingTarget . '.' . $listingTarget . '_data_source',
                                'selectionsProvider' => $listingTarget . '.' . $listingTarget . '.productfileupload_columns.ids',
                                'ns' => $listingTarget,
                                'render_url' => $this->urlBuilder->getUrl('mui/index/render'),
                                'realTimeLink' => true,
                                'dataLinks' => [
                                    'imports' => false,
                                    'exports' => true
                                ],
                                'behaviourType' => 'simple',
                                'externalFilterMode' => true,
                                'imports' => [
                                    'productId' => '${ $.provider }:data.productfileupload.current_product_id',
                                    'storeId' => '${ $.provider }:data.productfileupload.current_store_id',
                                ],
                                'exports' => [
                                    'productId' => '${ $.externalProvider }:params.current_product_id',
                                    'storeId' => '${ $.externalProvider }:params.current_store_id',
                                ]
                            ],
                        ],
                    ],
                ],
                
				
            ],
        ];
		
		

        return $modal;
    }
	
	
	
	protected function getProductFileUploadFormNext($listingTarget)
    {
        return [
			
				'arguments' => [
					'data' => [					
						'config' => [
							'label' => __('File Upload'),
							'componentType' =>  'file',
							'formElement' => 'fileUploader',
							'dataType' => Text::NAME,
						   // 'dataType' => Media::NAME,					
							'visible' => true,
							'additionalClasses'=> 'mcsfileupload',
							'disabled' => false,                    
							'dataScope' => 'fileupload',
							// 'scopeLabel' => $this->storeManager->isSingleStoreMode() ? '' : '[STORE VIEW]',
							
						],
					],
				],
			
           'children' => [],
	
        ];
		
    }
	
	
    
    /**
     * Retrieve button set
     *
     * @param Phrase $content
     * @param Phrase $buttonTitle
     * @param string $scope
     * @return array
     */
    protected function getButtonSet(Phrase $content, Phrase $buttonTitle, $scope)
    {
        //$modalTarget = $this->scopeName . '.' . static::GROUP_PFUTAB . '.' . $scope . '.modal';
		$modalTarget ='product_form.product_form.productfileupload.productfileupload.modal';
		$buttonTitle='Add File';
		$scope='productfileupload';

        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'formElement' => 'container',
                        'componentType' => 'container',
                        'label' => false,
                        'content' => $content,
                        'template' => 'ui/form/components/complex',
						'additionalClasses' => 'mcsfileupload-grid',
                    ],
                ],
            ],
            'children' => [
                'button_' . $scope => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'formElement' => 'container',
                                'componentType' => 'container',
                                'component' => 'Magento_Ui/js/form/components/button',
                                'actions' => [
                                    [
                                        'targetName' => $modalTarget,
                                        'actionName' => 'toggleModal',
                                    ],
                                    [
                                        'targetName' => $modalTarget . '.' . $scope . '_index_listing',
                                        'actionName' => 'render',
                                    ]
                                ],
                                'title' => $buttonTitle,
                                'provider' => null,
                            ],
                        ],
                    ],

                ],
            ],
        ];
    }

    /**
     * Prepares config for modal slide-out panel
     *
     * @param Phrase $title
     * @param string $scope
     * @return array
     */
    protected function getGenericModal(Phrase $title, $scope)
    {
        $listingTarget = $scope . '_index_listing';
		
		
        $modal = [
            'arguments' => [
                'data' => [
                    'config' => [
						
                        'componentType' => Modal::NAME,
                        'dataScope' => '',
                        'options' => [
                            'title' => $title,
                            'buttons' => [
                                [
                                    'text' => __('Cancel'),
                                    'actions' => [
                                        'closeModal'
                                    ]
                                ],
                                [
                                    'text' => __('Add Selected File'),
                                    'class' => 'action-primary add-assign-btn',
                                    'actions' => [
                                        [
                                            'targetName' => 'index = ' . $listingTarget,
                                            'actionName' => 'save'
                                        ],
                                        'closeModal'
                                    ]
                                ],
								
                            ],
                        ],						
						    
                    ],
                ],
            ],
            'children' => [
				//static::CONTAINER_HEADER_NAME => $this->getProductFileUploadForm(10),
				static::CONTAINER_HEADER_NAME => $this->getProductFileUploadFormNext($listingTarget),
								
                $listingTarget => [
                    'arguments' => [
                        'data' => [
                            'config' => [	
								
                                'autoRender' => false,
                                'componentType' => 'insertListing',
                                'dataScope' => $listingTarget,
                                'externalProvider' => $listingTarget . '.' . $listingTarget . '_data_source',
                                'selectionsProvider' => $listingTarget . '.' . $listingTarget . '.productfileupload_columns.ids',
                                'ns' => $listingTarget,
                                'render_url' => $this->urlBuilder->getUrl('mui/index/render'),
                                'realTimeLink' => true,
                                'dataLinks' => [
                                    'imports' => false,
                                    'exports' => true
                                ],
                                'behaviourType' => 'simple',
                                'externalFilterMode' => true,
                                'imports' => [
                                    'productId' => '${ $.provider }:data.productfileupload.current_product_id',
                                    'storeId' => '${ $.provider }:data.productfileupload.current_store_id',
                                ],
                                'exports' => [
                                    'productId' => '${ $.externalProvider }:params.current_product_id',
                                    'storeId' => '${ $.externalProvider }:params.current_store_id',
                                ],
								                                
								
                            ],
                        ],
                    ],
                ],
				
            ],
        ];
		
		

        return $modal;
    }

    /**
     * Retrieve grid
     *
     * @param string $scope
     * @return array
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function getGrid($scope)
    {
        $dataProvider = $scope . '_index_listing';
		
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'additionalClasses' => 'admin__field-wide',
                        'componentType' => DynamicRows::NAME,
                        'label' => null,
                        'columnsHeader' => false,
                        'columnsHeaderAfterRender' => true,
                        'renderDefaultRecord' => false,
                        'template' => 'ui/dynamic-rows/templates/grid',
                        'component' => 'Magento_Ui/js/dynamic-rows/dynamic-rows-grid',
                        'addButton' => false,
                        'recordTemplate' => 'record',
						'sortOrder' => 9,
                        'dataScope' => 'data.links',
                        'deleteButtonLabel' => __('Remove'),
                        'dataProvider' => $dataProvider,
                        'map' => [
                            'id' => 'entity_id',
                            'filename' => 'filename',
                            'filepath' => 'filepath',
                        ],
                        'links' => [
                            'insertData' => '${ $.provider }:${ $.dataProvider }'
                        ],
                        'sortOrder' => 2,
                    ],
                ],
            ],
            'children' => [
                'record' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => 'container',
                                'isTemplate' => true,
                                'is_collection' => true,
                                'component' => 'Magento_Ui/js/dynamic-rows/record',
                                'dataScope' => '',
                            ],
                        ],
                    ],
                    'children' => $this->fillMeta(),
                ],
            ],
        ];
    }

    /**
     * Retrieve meta column
     *
     * @return array
     */
    protected function fillMeta()
    {
        return [
            'id' => $this->getTextColumn('id', false, __('ID'), 0),            
            'filename' => $this->getTextColumn('filename', false, __('Filename'), 20),
            'filepath' => $this->getTextColumn('filepath', true, __('Filepath'), 30),
            
            'actionDelete' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'additionalClasses' => 'data-grid-actions-cell',
                            'componentType' => 'actionDelete',
                            'dataType' => Text::NAME,
                            'label' => __('Actions'),
                            'sortOrder' => 70,
                            'fit' => true,
                        ],
                    ],
                ],
            ],            
        ];
    }

    /**
     * Retrieve text column structure
     *
     * @param string $dataScope
     * @param bool $fit
     * @param Phrase $label
     * @param int $sortOrder
     * @return array
     */
    protected function getTextColumn($dataScope, $fit, Phrase $label, $sortOrder)
    {
        $column = [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'elementTmpl' => 'ui/dynamic-rows/cells/text',
                        'component' => 'Magento_Ui/js/form/element/text',
                        'dataType' => Text::NAME,
                        'dataScope' => $dataScope,
                        'fit' => $fit,
                        'label' => $label,
                        'sortOrder' => $sortOrder,
                    ],
                ],
            ],
        ];

        return $column;
    }
}