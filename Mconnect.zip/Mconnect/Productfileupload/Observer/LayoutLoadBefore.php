<?php
namespace Mconnect\Productfileupload\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
class LayoutLoadBefore implements ObserverInterface 
{
	protected $_request;
	
	/**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
	 
	 
	public function __construct(
       
        \Magento\Framework\App\Request\Http $request,
		\Magento\Framework\ObjectManagerInterface $objectManager,
        array $data = []
    )
    {        
        $this->_request = $request;
		$this->_objectManager = $objectManager;
        
    }	
    public function execute(\Magento\Framework\Event\Observer $observer)    {	
		if($this->_request->getFullActionName()=='catalog_product_view'){	
			
		$pfBlock = $this->_objectManager->create('Mconnect\Productfileupload\Block\Productfile');
		$productFiles= $pfBlock->getProductFilesCollection();
		
			if($productFiles->count()>0){
				//Nothin to do 
			}else{
				$layout = $observer->getData('layout');
				$layout->getUpdate()->addUpdate('<body><referenceBlock name="detailed_productfile_tab" remove="true" /></body>');
				
			}
			
		}
		                return $this;    }    
    
}