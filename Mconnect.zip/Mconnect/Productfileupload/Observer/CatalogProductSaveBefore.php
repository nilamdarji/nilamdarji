<?php
namespace Mconnect\Productfileupload\Observer;

use \Magento\Framework\Event\Observer;
use \Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;


class CatalogProductSaveBefore implements ObserverInterface {

	
		protected $scopeConfigObject;
	
		protected $_storeManager;
		
		protected $_request;
		
		protected $csmodel;
		
		protected $cscollection;
		
		protected $_csgCollection;
		
		protected $csgroup;
		
		
		
	
		public function __construct(					
			\Magento\Catalog\Helper\Product $catalogProductHelper,
			\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigObject,
			\Magento\Framework\App\RequestInterface $request,
			\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct\CollectionFactory $pfpCollection,
			StoreManagerInterface $storeManager
			){			
			$this->catalogProductHelper = $catalogProductHelper;			
			$this->scopeConfigObject = $scopeConfigObject;
			$this->_request = $request;
			$this->_storeManager = $storeManager;
			$this->_pfpCollection = $pfpCollection;

		}
	
   
   	 public function execute(Observer $observer) {			
		
			
		$product = $observer->getProduct();
		$product_id = $product->getId();
		$postData = $this->_request->getPostValue();
		
		
		
		if (array_key_exists('links', $postData)) {	
		
			if(array_key_exists('productfileupload', $postData["links"])){
				
				$productFileUploadId = $postData["links"]["productfileupload"];			
				$selectedId = array_column($productFileUploadId, 'id');
				
				
				$pfpCollection = $this->_pfpCollection->create();				
				$pfpCollection->addFieldToFilter('product_id',$product_id);	
				
				$oldIds = (array) $pfpCollection->getColumnValues('productfile_id');
                $newIds = (array) $selectedId;
				
				
				$this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');				
                $connection = $this->_resources->getConnection();
				
				$table = $this->_resources->getTableName(\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct::TBL_M_PF_PRODUCT);
				
				
                $insert = array_diff($newIds, $oldIds);
                $delete = array_diff($oldIds, $newIds);

                if ($delete) {
                    $where = ['product_id = ?' =>$product_id, 'productfile_id IN (?)' => $delete];
                    $connection->delete($table, $where);
                }

                if ($insert) {
                    $data = [];
                    foreach ($insert as $productfile_id) {
                        $data[] = ['productfile_id' => (int)$productfile_id, 'product_id' => (int)$product_id];
                    }
                    $connection->insertMultiple($table, $data);
                }	
		
		
			}
		}else{
			
			$pfpCollection = $this->_pfpCollection->create();				
			$pfpCollection->addFieldToFilter('product_id',$product_id);	
			$delete =(array) $pfpCollection->getColumnValues('productfile_id');
			
			$this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');				
                $connection = $this->_resources->getConnection();
				
			$table = $this->_resources->getTableName(\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct::TBL_M_PF_PRODUCT);
			
			if ($delete) {
                    $where = ['product_id = ?' =>$product_id, 'productfile_id IN (?)' => $delete];
                    $connection->delete($table, $where);
                }
				 
					
			
		}
			
		
	}
   
}