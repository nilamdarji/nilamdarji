<?php 
namespace Mconnect\Productfileupload\Setup;
 
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
 
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrades DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
 
        /**
         * Create table 'mconnect_productfile_product'
         */
         
		
        if (version_compare($context->getVersion(), '2.0.2') < 0) {
			
			
			$table = $installer->getConnection()->newTable(
            $installer->getTable('mconnect_productfile_product')				
			)->addColumn(
				'rel_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				null,
				['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
				'Relation ID'
			)->addColumn(
				'productfile_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				32,
				[],
				'ProductFile ID'
			)->addColumn(
				'product_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				32,
				[],
				'Product ID'
			)->addColumn(
				'position',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				null,
				[],
				'Position'
			);  
          
            $installer->getConnection()->createTable($table);          
 
        }
		
		
		
        if (version_compare($context->getVersion(), '2.0.4') < 0) {
			
			
			$table = $installer->getConnection()->newTable(
            $installer->getTable('mconnect_productfile_store')				
			)->addColumn(
				'productfile_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				32,
				['nullable' => false, 'primary' => true],
				'ProductFile ID'
			)->addColumn(
				'store_id',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				32,
				[ 'unsigned' => true, 'nullable' => false, 'primary'  => true],
				'Store ID'
			);  
          
            $installer->getConnection()->createTable($table);          
 
        }	
			
 
        $installer->endSetup();
    }
}