<?php
namespace Mconnect\Productfileupload\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper 
{
    /**
     * Functionality to get configuration values of plugin
     *
     * @param $configPath: System xml config path
     * @return value of requested configuration
     */
	 public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Mconnect\Productfileupload\Helper\McsHelper $mcsHelper
	 )
	 {
		 $this->mcsHelper = $mcsHelper;
		 parent::__construct($context);
	 }
    public function getConfig($configPath) {
        return $this->scopeConfig->getValue(
			$configPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	
	public function getProductFileTemplate()
    {
		$template ='';
		
		if ($this->mcsHelper->checkLicenceKeyActivation() ) {
        $template =  'Mconnect_Productfileupload::productfile/productfile.phtml';
		}	
       
        return $template;
                
    }
	
	
}