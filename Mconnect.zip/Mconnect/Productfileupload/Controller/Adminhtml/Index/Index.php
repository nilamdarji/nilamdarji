<?php
namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
	protected $resultPageFactory;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
		$resultPage->setActiveMenu('Mconnect_Productfileupload::productfileupload');
        $resultPage->addBreadcrumb(__('ProductFileUpload'), __('ProductFileUpload'));
        $resultPage->addBreadcrumb(__('Manage ProductFileUpload'), __('Manage ProductFileUpload'));
        $resultPage->getConfig()->getTitle()->prepend(__('Product File Upload'));
        return $resultPage;
    }
}