<?php
namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Ui\Component\MassAction\Filter;

class MassDelete extends \Magento\Backend\App\Action
{
	protected $_coreRegistry = null;

	protected $resultPageFactory;

	protected $_productFileCollection;
   
    public function __construct(
		Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\Registry $registry,
		Filter $filter,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfile\CollectionFactory $productFileFactory
    ) {
		$this->resultPageFactory = $resultPageFactory;
		$this->_coreRegistry = $registry;
		$this->_productFileCollection = $productFileFactory;
		$this->filter = $filter;
		parent::__construct($context);
    }

    public function execute()
    {
		$collection = $this->filter->getCollection($this->_productFileCollection->create());	
		$count = 0;
        foreach ($collection as $pfuArray) {
			$pfuArray->delete();
			$count++;
        }
        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $count));
        $resultRedirect = $this->resultRedirectFactory->create();		
        return $resultRedirect->setPath('*/*/');
    }
}
