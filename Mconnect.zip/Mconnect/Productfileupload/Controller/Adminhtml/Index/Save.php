<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Backend\Helper\Js;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Backend\App\Action
{
	
	protected $_productfileFactory;
	
	protected $_jsHelper;
	
	protected $_date;
	
	protected $_fileUploaderFactory;
	
	protected $_fileSystem;
	
	protected $_pfCollection;
	
	protected $_pfpCollection;

	protected $_pfuHelper;	

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     */
    public function __construct(
		Action\Context $context, 
		\Mconnect\Productfileupload\Model\ProductfileFactory $productfile,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfile\CollectionFactory $pfCollection,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct\CollectionFactory $pfpCollection,
		\Mconnect\Productfileupload\Helper\Data $pfuHelper,
		\Magento\Framework\Stdlib\DateTime\DateTime $date,
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploader,
		\Magento\Framework\Filesystem $fileSystem,
		\Magento\Backend\Helper\Js $jsHelper
	){
		$this->_productfileFactory = $productfile;
		$this->_pfCollection = $pfCollection;
		$this->_pfpCollection = $pfpCollection;
		$this->_pfuHelper = $pfuHelper;
		$this->_date = $date;
		$this->_fileUploaderFactory = $fileUploader;
		$this->_fileSystem = $fileSystem;
		$this->_jsHelper = $jsHelper;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Productfileupload::save');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

	$allowedExtensions=$this->_pfuHelper->getConfig('mconnect_productfileupload/general/fileextensions');	
	$allowedExtensions_SourceArr = explode(',',$allowedExtensions);
	$allowedExtensions_Arr = array();
        foreach($allowedExtensions_SourceArr as $val)
        {            
            $allowedExtensions_Arr[] = trim($val);
        }
		
		
        $data = $this->getRequest()->getPostValue();
        $data1 = $this->getRequest()->getPostValue();
		unset($data['filepath']);
		$dateTime = $this->_date->gmtDate();		
		
		/** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
		
		if($data){
			
			$productfileModel = $this->_productfileFactory->create();
			$productfileModel->setData($data)->setId($this->getRequest()->getParam('id'));
			
			try {
					if(isset($data1['filepath']['delete']))
					{
						$fileName = $data1['filepath']['value'];
						$mediaRootDir = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath('productfileupload');

						if ($this->_objectManager->get('Magento\Framework\Filesystem\Driver\File')->isExists($mediaRootDir . $fileName))  {

							$this->_objectManager->get('Magento\Framework\Filesystem\Driver\File')->deleteFile($mediaRootDir . $fileName);
						}
						$productfileModel->setData('filesize', '00');
						$productfileModel->setData('filepath', '');
					}
					
					else if(isset($_FILES['filepath']['name']) && $_FILES['filepath']['name'] != '') {
															
						try {
							$uploader = $this->_fileUploaderFactory->create(['fileId' => 'filepath']);
							$uploader->setAllowedExtensions($allowedExtensions_Arr);
							
							$uploader->setAllowRenameFiles(true);
							$uploader->setFilesDispersion(true);
							$path = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)
							->getAbsolutePath('productfileupload');
							$result = $uploader->save($path);							
									
							$filesize=$result['size'];
							$filepath= $uploader->getUploadedFilename();
							
							$productfileModel->setData('filesize', $filesize);
							$productfileModel->setData('filepath', $filepath);
							
							
						}catch (\Magento\Framework\Exception\LocalizedException $e) {
							$this->messageManager->addError($e->getMessage());
						} catch (\RuntimeException $e) {
							$this->messageManager->addError($e->getMessage());
						} catch (\Exception $e) {
							$this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the page.'));
						}
			
					}		
					
					
					
				
				if(!$this->getRequest()->getParam('id')){
				$productfileModel->setData('created_at',$dateTime);	
				}			
				$productfileModel->setData('updated_at',$dateTime);			
				
				$productfileModel->save();
				
				$this->saveProducts($productfileModel, $data);
				
				
				$this->messageManager->addSuccess(__('File was successfully saved'));
				$this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
				
				if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $productfileModel->getId(), '_current' => true]);
                }
				$this->_redirect('*/*/');
				return;
				
			}catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the page.'));
            }
			
		}
		
		        
        return $resultRedirect->setPath('*/*/');
    }

	
	
	public function saveProducts($productfileModel, $post)
    {
        // Attach the attachments to pfu_product_ids
		
        if (isset($post['pfu_product_ids'])) {
            $productIds = $this->_jsHelper->decodeGridSerializedInput($post['pfu_product_ids']);
            try {
								
				$productfile_id=$productfileModel->getId();	
				
				$pfpCollection = $this->_pfpCollection->create();				
				$pfpCollection->addFieldToFilter('productfile_id',$productfile_id);				
				
				$oldProducts = (array) $pfpCollection->getColumnValues('product_id');
                $newProducts = (array) $productIds;
								
				$this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');				
                $connection = $this->_resources->getConnection();
				
				$table = $this->_resources->getTableName(\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct::TBL_M_PF_PRODUCT);
				
				
                $insert = array_diff($newProducts, $oldProducts);
                $delete = array_diff($oldProducts, $newProducts);

                if ($delete) {
                    $where = ['productfile_id = ?' => (int)$productfileModel->getId(), 'product_id IN (?)' => $delete];
                    $connection->delete($table, $where);
                }

                if ($insert) {
                    $data = [];
                    foreach ($insert as $product_id) {
                        $data[] = ['productfile_id' => (int)$productfileModel->getId(), 'product_id' => (int)$product_id];
                    }
                    $connection->insertMultiple($table, $data);
                }					
					
				
            } catch (Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the FAQ.'));
            }
        }

    }
	
}
