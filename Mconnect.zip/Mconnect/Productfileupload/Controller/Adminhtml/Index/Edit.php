<?php

namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Mconnect\Productfileupload\Model\ProductfileFactory;


class Edit extends \Magento\Backend\App\Action
{
    protected $_coreRegistry = null;
    
    protected $resultPageFactory;
	
	protected $_productfileFactory;


    
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		 ProductfileFactory $productfile
		
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		$this->_productfileFactory = $productfile;

        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Productfileupload::save');
    }

    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Mconnect_Productfileupload::Productfileupload')
            ->addBreadcrumb(__('PFU'), __('PFU'))
            ->addBreadcrumb(__('Manage PFU'), __('Manage PFU'));
        return $resultPage;
    }

    public function execute()
    { 			
		
		$id = $this->getRequest()->getParam('id');
		$productfileModel = $this->_productfileFactory->create();
		
		if ($id){				
			$productfileModel->load($id);			
            if (!$productfileModel->getId()) {
                $this->messageManager->addError(__('This product file no longer exists.'));
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
		
        
		
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
			
            $productfileModel->setData($data);
            
        }
		
        $this->_coreRegistry->register('productfile', $productfileModel);
		
        $resultPage = $this->_initAction();
		$resultPage->getConfig()->getTitle()->prepend(__('Product File Upload'));		
		$resultPage->getConfig()->getTitle()
            ->prepend($productfileModel->getId() ? $productfileModel->getFilename() : __('Product File Upload'));			
        return $resultPage;
    }
}
