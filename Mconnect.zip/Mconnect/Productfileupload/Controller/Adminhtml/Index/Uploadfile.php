<?php
/**
 *
 * Copyright � 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Backend\Helper\Js;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;


class Uploadfile extends \Magento\Backend\App\Action
{
	
	protected $_productfileFactory;
	
	protected $_jsHelper;
	
	protected $_date;
	
	protected $_fileUploaderFactory;
	
	protected $_fileSystem;
	
	protected $_pfCollection;
	
	protected $_pfpCollection;	
	
	protected $_pfuHelper;	

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     */
	 
    public function __construct(
		Action\Context $context, 
		\Mconnect\Productfileupload\Model\ProductfileFactory $productfile,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfile\CollectionFactory $pfCollection,
		\Mconnect\Productfileupload\Model\ResourceModel\Productfileproduct\CollectionFactory $pfpCollection,
		\Mconnect\Productfileupload\Helper\Data $pfuHelper,
		\Magento\Framework\Stdlib\DateTime\DateTime $date,
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploader,
		\Magento\Framework\Filesystem $fileSystem,
		\Magento\Backend\Helper\Js $jsHelper
	){
		$this->_productfileFactory = $productfile;
		$this->_pfCollection = $pfCollection;
		$this->_pfpCollection = $pfpCollection;
		$this->_pfuHelper = $pfuHelper;
		$this->_date = $date;
		$this->_fileUploaderFactory = $fileUploader;
		$this->_fileSystem = $fileSystem;
		$this->_jsHelper = $jsHelper;		
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Productfileupload::productfileupload_save');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		
		$store_id = $this->getRequest()->getParam('store_id');		
		
		$allowedExtensions=$this->_pfuHelper->getConfig('mconnect_productfileupload/general/fileextensions');	
		$allowedExtensions_SourceArr = explode(',',$allowedExtensions);
		$allowedExtensions_Arr = array();
        foreach($allowedExtensions_SourceArr as $val)
        {            
            $allowedExtensions_Arr[] = trim($val);
        }
		
		
		try {
				$uploader = $this->_fileUploaderFactory->create(['fileId' => 'input_file_name']);
				
				$uploader->setAllowedExtensions($allowedExtensions_Arr);
				
				$uploader->setAllowRenameFiles(true);
				$uploader->setFilesDispersion(true);
				$path = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)
				->getAbsolutePath('productfileupload');
				$result = $uploader->save($path);							
						
				$filesize=$result['size'];
		        $filepath= $uploader->getUploadedFilename();
				
				$filename_arr = explode('/',$filepath);
                $filename_str = $filename_arr[count($filename_arr)-1];
				$withoutExt = preg_replace('/\\.[^.\\s]{2,4}$/', '', $filename_str);				
				$filename=$withoutExt;
				
				
				$productfileModel = $this->_productfileFactory->create();
				$dateTime = $this->_date->gmtDate();
				
				$productfileModel->setData('filename', $filename);				
				$productfileModel->setData('filepath', $filepath);
				$productfileModel->setData('filesize', $filesize);
				$productfileModel->setData('status', 1);
				$productfileModel->setData('created_at',$dateTime);							
				$productfileModel->setData('updated_at',$dateTime);
				$productfileModel->save();
				
				
				$productfile_id=$productfileModel->getId();					
				$this->saveStoreData($productfile_id, $store_id);
					
				
				$responseData = [
						'errors' => false,
						'productfile_id' => $productfile_id,
						'message'=>'sucess fully add',
						];
				
				
			}catch (\Magento\Framework\Exception\LocalizedException $e) {
				$this->messageManager->addError($e->getMessage());
				$responseData = [
						'errors' => true,						
						'message'=>$e->getMessage(),
						];
				
			} catch (\RuntimeException $e) {
				$this->messageManager->addError($e->getMessage());
				$responseData = [
						'errors' => true,
						'message'=>$e->getMessage(),
						];
						
			} catch (\Exception $e) {
				$this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the page.'));
				$responseData = [
						'errors' => true,
						'message'=>$e->getMessage(),
						];
			}
			
				
				$resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);  
				$resultJson->setData($responseData);
				return $resultJson;	
	
	   exit('exithere');
    }
	
	
	public function saveStoreData($productfile_id, $store_id)
    {
		
		$this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');

		$storeIds=[];
		$storeIds[]=0;
		//$storeIds[]=$store_id;
		
        $connection = $this->_resources->getConnection();				
		$table = $this->_resources->getTableName('mconnect_productfile_store');				
		$data = [];
		
		$storeIds=array_unique($storeIds);		
		foreach ($storeIds as $store_id_dt) {
        $data[] = ['productfile_id' => (int)$productfile_id, 'store_id' => $store_id_dt]; 
         }		     
		$connection->insertMultiple($table, $data);
		
	}
	
	
}
