<?php
namespace Mconnect\Productfileupload\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Delete extends \Magento\Backend\App\Action
{
    protected $_coreRegistry = null;  
	
    protected $resultPageFactory;	
	
	protected $_productfileFactory;	
	


    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		\Mconnect\Productfileupload\Model\ProductfileFactory $productfile
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		$this->_productfileFactory = $productfile;
        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Productfileupload::delete');
    }

    
    public function execute()
    { 
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('id');
		
        $productfileModel = $this->_productfileFactory->create();
        
        $resultRedirect = $this->resultRedirectFactory->create();
		
        if(isset($id)){			
			
           
			
            try {
				
				$title = "";
				
                $productfileModel->load($id);                
                $title = $productfileModel->getId();
				
				$fileName = $productfileModel->getFilepath();	
				$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
				$mediaRootDir = $mediaDirectory->getAbsolutePath('productfileupload');
				//echo $mediaRootDir . $fileName; exit;
				if ($this->_objectManager->get('Magento\Framework\Filesystem\Driver\File')->isExists($mediaRootDir . $fileName))  {
					$this->_objectManager->get('Magento\Framework\Filesystem\Driver\File')->deleteFile($mediaRootDir . $fileName);
				}
				
                $productfileModel->delete();
               
                // display success message
                $this->messageManager->addSuccess(__('The Product File Upload has been deleted.'));
                // go to grid
                $this->_eventManager->dispatch(
                    'adminhtml_pfu_on_delete',
                    ['title' => $title, 'status' => 'success']
                );
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                
                // display error message
                $this->messageManager->addError($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addError(__('We can\'t find a pfu to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}
