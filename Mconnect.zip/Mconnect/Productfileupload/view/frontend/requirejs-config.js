var config = {
    map: {
        '*': {			
			productfileupload : 'Mconnect_Productfileupload/js/productfileupload',		
        }
    }
};