<?php

namespace Mconnect\Custom\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order\Email\Sender\OrderCommentSender;
use Magento\Store\Model\StoreManagerInterface;

class OrderSaveAfter implements ObserverInterface
{

    protected $orderCommentSender;
    protected $_transportBuilder;
    protected $storeManager;
    protected $_inlineTranslation;
    protected $_logLoggerInterface;

    public function __construct(
        OrderCommentSender $orderCommentSender,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
		 \Psr\Log\LoggerInterface $loggerInterface
    )
    {
        $this->orderCommentSender = $orderCommentSender;
        $this->_transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_logLoggerInterface = $loggerInterface;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        if ($order->getState() == 'canceled') {
            $this->orderCommentSender->send($order, true);
            // $from = [
            //     'name' => 'Vijay Chudasama',
            //     'email' => 'vijay@magentoconnect.us'
            // ];
            // try
            // {
            //     // Send Mail
            //     $this->_inlineTranslation->suspend();

            //     /** @var $this->_transportBuilder \Magento\Framework\Mail\Template\TransportBuilder */ 
                
            //     $transport = $this->_transportBuilder
            //          ->setTemplateIdentifier('cancel_order_email_template')
            //          ->setTemplateOptions( ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId()] )
            //          ->setTemplateVars([
            //             'firstname'  => 'vishal',
            //             'lastname' => 'rathod',
            //             'email'  => 'vishalr@magentoconnect.us',
            //             'order_id'=>$order->getEntityId()
                        
            //          ] )
            //          ->setFrom($from)
            //          ->addTo('vishalr@magentoconnect.us');
    
            //         try {
    
            //             $this->_transportBuilder->getTransport()->sendMessage();
    
            //         } catch (Exception $e) {
            //             $this->_logLoggerInterface->critical($e->getMessage());
            //         }
    
            // } catch(\Exception $e){
            //     $this->_logLoggerInterface->debug($e->getMessage());
            //     exit;
            // }
        }
    }
}