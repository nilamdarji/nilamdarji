<?php 
namespace Mconnect\Custom\Block;

class SubCategories extends \Magento\Framework\View\Element\Template
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
	//protected $_registry;
	/**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $_categoryFactory;

    /**
     * @var \Magento\Catalog\Helper\Category
     */
    protected $_categoryHelper;

	/**
     * @var \Mconnect\Custom\Helper\Image
     */
    protected $_imageHelper;

	/**
     * @var maxcatlevel
     */
    protected $_maxcatlevel;
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Catalog\Helper\Category $categoryHelper
     * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     * @param \Mconnect\Custom\Helper\Image $imageHelper
     * @param array $data
     */

    
    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        return $this;
    }
	
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Category $categoryHelper,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $collectionFactory,
		\Mconnect\Custom\Helper\Image $imageHelper
    ) {
        $this->_categoryHelper = $categoryHelper;
        $this->_coreRegistry = $registry;
        $this->_categoryFactory = $categoryFactory;
        $this->_collectionFactory = $collectionFactory;
		$this->_imageHelper = $imageHelper;
        parent::__construct($context);
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getCurrentCategory()
    {
        if (!$this->hasData('current_category')) {
            $this->setData('current_category', $this->_coreRegistry->registry('current_category'));
        }
        return $this->getData('current_category');
    }

    /**
     * Retrieve category model object
     * @param category id
     * @return \Magento\Catalog\Model\Category
     */
    public function getCategory($id)
    {   
        return $this->_categoryFactory->create()->load($id);
	}
	
	public function getSubCategoryList()
    {
		$_category  = $this->getCurrentCategory();
		$collection = $this->_categoryFactory->create()->getCollection()
			->addAttributeToSelect('*')
			->addAttributeToFilter('is_active', 1)
			->setOrder('position', 'ASC')
			->addIdFilter($_category->getChildren());
      	return $collection;
    }

    /**
     * get category thumbnail
     * @param category
     * @return string|null
     */
    public function getCategoryThumbnail($category, $width=500, $height=300)
    {
		$image = 'placeholder.jpg';
		if ($category->getThumbNail()) {
			$image = $category->getThumbNail();
		}elseif ($category->getImage()) {
			$image = $category->getImage();
		}

        return $this->_imageHelper->resize($image,$width, $height);
    }


    //CUSTUM CODE start 

    public function getCategoryChildrenIds()
    {
        $_category  = $this->getCurrentCategory();
        $subcategories = $_category->getChildrenCategories();
        $sub_array = [];
        foreach ($subcategories as $subcategory) {
            array_push($sub_array,$subcategory->getId());
        }
        return $sub_array;
    }
    
}  


