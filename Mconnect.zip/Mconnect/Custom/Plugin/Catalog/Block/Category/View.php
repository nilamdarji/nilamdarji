<?php
namespace Mconnect\Custom\Plugin\Catalog\Block\Category;

class View
{
    public function beforeToHtml(\Magento\Catalog\Block\Category\View $subject)
    {
        if ($subject->getTemplate() === 'Magento_Catalog::category/products.phtml') {
            $subject->setTemplate('Mconnect_Custom::catalog/category/products.phtml');
        }
    }
}