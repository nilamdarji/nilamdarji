<?php
declare(strict_types=1);

namespace Mconnect\Custom\Plugin\Magento\Catalog\Model\Category\Attribute\Source;

class Mode
{

    public function afterGetAllOptions(
        \Magento\Catalog\Model\Category\Attribute\Source\Mode $subject,
        $result
    ) {
        
        $result[] = ['value' => 'CATEGORY_ONLY', 'label' => 'Category Only'];
        $result[] = ['value' => 'CATEGORY_PRODUCT', 'label' => 'Category and Product'];
        $result[] = ['value' => 'CATEGORY_SUBCAT', 'label' => 'Category and Sub Category'];

        return $result;
    }
}

