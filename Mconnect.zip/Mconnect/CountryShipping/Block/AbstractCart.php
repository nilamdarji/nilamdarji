<?php
namespace Mconnect\CountryShipping\Block;

class AbstractCart
{
    public function afterGetItemRenderer(\Magento\Checkout\Block\Cart\AbstractCart $subject, $result)
    {
        $result->setTemplate('Mconnect_CountryShipping::cart/item/default.phtml');
        return $result;
    }
}
