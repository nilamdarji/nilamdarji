<?php

namespace Mconnect\CountryShipping\Block\Adminhtml\Product\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Mconnect\CountryShipping\Model\Countryshipping;
use \Magento\Directory\Model\Config\Source\Country;
use Mconnect\CountryShipping\Model\ResourceModel\Countryshipping\CollectionFactory;

class Countryshippingtab extends \Magento\Framework\View\Element\Template
{
    protected $_template = 'Countryshippingtab.phtml';

    protected $coreRegistry = null;

    protected $scopeConfig;
    
    protected $sppcModule;
    
    protected $countries;
    
    protected $sppcCollection;
    
    public function __construct(
        Context $context,
        Registry $registry,
        Countryshipping $sppcModule,
        Country $countries,
        CollectionFactory $sppccollection,
        array $data = []
    ) {
    
        $this->coreRegistry = $registry;
        $this->sppcModule  = $sppcModule;
        $this->countries  = $countries;
        $this->sppcCollection = $sppccollection;
        $this->scopeConfig = $context->getScopeConfig();
        parent::__construct($context, $data);
    }
    public function _getAllCountries()
    {
        $countries = $this->countries->toOptionArray(); //Load an array of countries

        foreach ($countries as $countryKey => $country) {
            if ($country['value'] != '') { //Ignore the first (empty) value
                    $_allowedCountriesArray[]=$country;
            }
        }
        return $_allowedCountriesArray;
    }
    public function getAllowedCountries()
    {
        if ($this->getEnableShiptoApplicableCountries()) {
            $SpecificCountries=$this->getShiptoSpecificCountries();
            if ($SpecificCountries!='') {
                $allCountriesArray = $this->_getAllCountries();
                $SpecificCountries = explode(",", $SpecificCountries);
                $countriesArray = [];
                $i=0;
                foreach ($allCountriesArray as $country) {
                    if (in_array($country['value'], $SpecificCountries)) {
                        $countriesArray[$i]['value'] = $country['value'];
                        $countriesArray[$i]['label'] = $country['label'];
                        $i++;
                    }
                }
                $allowedCountriesArray=$countriesArray;
            } else {
                $allowedCountriesArray = [];
            }
        } else {
            $allowedCountriesArray= $this->_getAllCountries();
        }
        return $allowedCountriesArray;
    }
    public function getEnableCountrySelection()
    {
        return  $this->scopeConfig->
        getValue(
            'carriers/mconnectship/enable_country_selection',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getStoreId()
        );
    }
    public function getEnableCountryRestriction()
    {
        return  $this->scopeConfig->
        getValue(
            'carriers/mconnectship/enable_country_restriction',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getStoreId()
        );
    }
    public function getEnableShiptoApplicableCountries()
    {
        return  $this->scopeConfig->
        getValue(
            'carriers/mconnectship/sallowspecific',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getStoreId()
        );
    }
    public function getShiptoSpecificCountries()
    {
        return  $this->scopeConfig->
        getValue(
            'carriers/mconnectship/specificcountry',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getStoreId()
        );
    }
    public function getProductId()
    {
         return $this->coreRegistry->registry('product')->getId();
    }
    public function getProduct()
    {
        return $this->coreRegistry->registry('current_product');
    }
    public function getProductSpppcData()
    {
        
        $sppccollectiondata = $this->sppcModule->getCollection()->
        addFieldToFilter('product_id', ["eq" => $this->getProductId()])->
        addFieldToFilter('store_id', ["eq" => $this->getStoreId()]);
        
        if ($sppccollectiondata->getSize() && $this->getProductId()>0 && !empty($this->getProductId())) {
            return $sppccollectiondata;
        }
        $sppccollectiondata = $this->sppcModule->getCollection()->
        addFieldToFilter('product_id', ["eq" => $this->getProductId()])->
        addFieldToFilter('store_id', ["eq" => 0]);
        if ($sppccollectiondata->getSize() && $this->getProductId()>0 && !empty($this->getProductId())) {
            return $sppccollectiondata;
        }
        return '';
    }
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }
}
