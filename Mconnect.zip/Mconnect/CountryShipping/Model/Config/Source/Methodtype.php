<?php
namespace Mconnect\CountryShipping\Model\Config\Source;

class Methodtype implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => 'p', 'label' => __('Per Product')],
            ['value' => 'o', 'label' => __('Per Order')],
        ];
    }
}
