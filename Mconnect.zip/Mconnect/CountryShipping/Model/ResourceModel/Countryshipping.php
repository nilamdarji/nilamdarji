<?php
namespace Mconnect\CountryShipping\Model\ResourceModel;
 
use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
/**
 * Shippingperproductcountries post mysql resource
 */
class Countryshipping extends AbstractDb
{
 
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        // Table Name and Primary Key column
        $this->_init('shippingperproduct_countries', 'sppc_id');
    }
}
