<?php
namespace Mconnect\CountryShipping\Model\ResourceModel\Countryshipping;
 
use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
 
    protected $_idFieldName = \Mconnect\CountryShipping\Model\Countryshipping::SPPC_ID;
     
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Mconnect\CountryShipping\Model\Countryshipping',
            'Mconnect\CountryShipping\Model\ResourceModel\Countryshipping'
        );
    }
}
