<?php
namespace Mconnect\CountryShipping\Model\Carrier;
 
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Rate\Result;
use \Mconnect\CountryShipping\Model\Countryshipping;
use Magento\Catalog\Model\Product;
use Magento\GroupedProduct\Model\Product\Type\Grouped;
use Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable;
use Magento\Bundle\Model\Product\Type;
use \Magento\Shipping\Model\Carrier\AbstractCarrier;
use \Magento\Shipping\Model\Carrier\CarrierInterface;
use \Magento\Framework\App\Request\Http;
use Magento\Store\Model\StoreManagerInterface;

class Countryshippingcarrier extends AbstractCarrier implements CarrierInterface
{
    /**
     * @var string
     */
    protected $_code = 'mconnectship';
    protected $sppcModule;
    protected $productModule;
    protected $groupedProductModule;
    protected $configurableProductModule;
    protected $typeProductModule;
    protected $quoteRepository;
    protected $req;
    protected $storeManager;
    
    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        Countryshipping $sppcModule,
        Product $productModule,
        Grouped $groupedProductModule,
        Configurable $configurableProductModule,
        Type $typeProductModule,
        StoreManagerInterface $storeManager,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        Http $reqst,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->sppcModule  = $sppcModule;
        $this->productModule  = $productModule;
        $this->groupedProductModule  = $groupedProductModule;
        $this->configurableProductModule = $configurableProductModule;
        $this->typeProductModule =$typeProductModule;
        $this->storeManager = $storeManager;
        $this->quoteRepository = $quoteRepository;
        $this->req = $reqst;
		$i=0;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }
 
    /**
     * @return array
     */
    public function getAllowedMethods()
    {
        return ['flatrate' => $this->getConfigData('name')];
    }
    public function getPost()
    {
        return $this->req->getPost();
    }
    
    public function getcontrollername()
    {
        return $this->req->getRouteName();
    }
 
    /**
     * @param RateRequest $request
     * @return bool|Result
     */
    public function collectRates(RateRequest $request)
    {
		 $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		 $logger = $objectManager->create('\Psr\Log\LoggerInterface');
        if (!$this->getConfigFlag('active')) {
            return false;
        }
        $perOrderRate = [];
        $shippingPrice = 0;
        $DefaultProductShippingCost=0;
        
        $MethodType= $this->getConfigData('type');
        $MaxMin = $this->getConfigData('max_min');
        
        $DisplayDefaultRate =$this->getConfigData('shipping_default_value_enable');
        if ($DisplayDefaultRate) {
                $DefaultProductShippingCost= $this->getConfigData('default_shipping_cost');
				$logger->info('default Test: '.$DefaultProductShippingCost);
        }
        
        $MultiplyQty= $this->getConfigData('multiply_qty');
        
        $AllowFreeShipping =$this->getConfigData('allow_free_shipping');
        $FreeShippingOverTotal =(float)$this->getConfigData('free_shipping_over_total');
        
        $countryId =  $request->getDestCountryId();
        $this->_logger->addDebug('Country id='.$countryId);
        
        $items = $request->getAllItems();
        
        if (!empty($items)) {
        /** @var \Magento\Shipping\Model\Rate\Result $result */
            $result = $this->_rateResultFactory->create();
            
            $shippingPriceFinal = 0;
            $isChidrenQty = false;
            $chidrenTotal = 0 ;
            $lastProductType = "";
            $isparentQty = false;
            $parentQty=0;
           
            foreach ($items as $item) {
                $product      = $this->productModule->load($item->getProductId());
                $productQty   =  $item->getQty();
                $type_id = $product->getTypeId();
                $is_perproduct_rate=0;
                $this->_logger->addDebug('product type '.$product->getTypeId());
                if (($item->getIsVirtual() ||
                $type_id == 'virtual' ||
                $type_id == 'configurable' ||
                $type_id == 'downloadable' ||
                $type_id == 'grouped' ||
                $type_id == 'bundle')) {
                    $isChidrenQty = true;
                    $chidrenTotal = $productQty;
                    continue;
                }
                
                $cartquote=$this->quoteRepository->get($item->getQuoteId());
                
                $data=$this->getSppcCollectionData($item->getProductId(), $this->getStoreId());
                $is_perproduct_rate=$this->getProductRateData($data, $countryId);
				if($is_perproduct_rate!=NULL || $is_perproduct_rate==0 ){
					$logger->info('First Test: '.$is_perproduct_rate);
				}else{
					$logger->info('Null Return: '.$is_perproduct_rate);
				}
				
                $this->_logger->addDebug('default product rate  '.$is_perproduct_rate);
                $logger->info('default product rate  '.$is_perproduct_rate);
                if ($item->getParentItemId()) {
                    $quoteItem = $cartquote->getItemById($item->getParentItemId());
                    $isparentQty = true;
                    $parentQty = $quoteItem->getQty();
                }
                if ($product->getTypeId() == "simple" && (  is_null($is_perproduct_rate) ) ) {
                    $this->_logger->addDebug('Checking in parent');
                    if ($item->getParentItemId()) {
                        $parentIds=$quoteItem->getProductId();
                    } else {
                        $parentIds = $this->groupedProductModule->getParentIdsByChild((int)$product->getId());
                        if (isset($parentIdstemp[0])) {
                            $parentIds =$parentIdstemp[0];
                        }
                    }
					//$logger->info('parent : '.$parentIds);
                    if (isset($parentIds) && !empty($parentIds)) {
                        $parent = $this->productModule->load($parentIds);
                        $parent_data=$this->getSppcCollectionData($parentIds, $this->getStoreId());
                        $is_perproduct_rate=$this->getProductRateData($parent_data, $countryId);
						$logger->info('parent Id: '.$is_perproduct_rate);
                        $this->_logger->addDebug(' parents rate  '.$is_perproduct_rate);
                    }
                }
                
                if ( ( is_null($is_perproduct_rate)  ) && $DisplayDefaultRate ) {
                        $this->_logger->addDebug(' global rate  '.$DefaultProductShippingCost);
						$logger->info('Global Rate: '.$is_perproduct_rate);
                        $is_perproduct_rate = $DefaultProductShippingCost;
                }
                if ($MultiplyQty) {
                    $mqpf=($productQty * $is_perproduct_rate);
                    if ($isparentQty) {
                        $mqpf = ($parentQty * $mqpf);
                        $isparentQty = false;
                        $parentQty = 0;
                    }
                    $shippingPriceFinal +=$mqpf;
                } else {
                       $shippingPriceFinal += ($is_perproduct_rate);
                }
                $perOrderRate[] = $is_perproduct_rate;
                $lastProductType = "";
            }
            $shippingPrice += $shippingPriceFinal;
        } else {
            $shippingPrice = false;
        }
        $this->_logger->addDebug('Final price a '.$shippingPrice);
        if ($MethodType == 'o') {
             $min_max = ($MaxMin) ? $MaxMin : "max";
            if ($min_max == "max") {
                $shippingPrice = max($perOrderRate);
            } else {
                $shippingPrice = min($perOrderRate);
            }
        }
        $logger->info('sprice  '.$shippingPrice);
        $shippingPrice = $this->getFinalPriceWithHandlingFee($shippingPrice);
         
        $grandTotal = $request->getBaseSubtotalInclTax();
        
        if ($AllowFreeShipping && $FreeShippingOverTotal < $grandTotal) {
                    $shippingPrice = 0.00;
        }
		$logger->info('Last  '.$is_perproduct_rate);
        if ($shippingPrice !== false) {
			$logger->info('sprice last  '.$shippingPrice);
            /** @var \Magento\Quote\Model\Quote\Address\RateResult\Method $method */
            $method = $this->_rateMethodFactory->create();
     
            $method->setCarrier($this->_code);
            $method->setCarrierTitle($this->getConfigData('title'));
     
            $method->setMethod($this->_code);
            $method->setMethodTitle($this->getConfigData('name'));
     
            $method->setPrice($shippingPrice);
            $method->setCost($shippingPrice);
            
            $result->append($method);
        }
        return $result;
    }
    public function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }
    public function getSppcCollectionData($product_id, $store_id)
    {
         
        $sppccollectiondata = $this->sppcModule->getCollection()->
                addFieldToFilter('product_id', $product_id)->
                addFieldToFilter('store_id', $store_id)->getFirstItem();
        
        if (!empty($sppccollectiondata->getData())) {
            $data=$sppccollectiondata->getData();
            return $data;
        }
        $sppccollectiondata = $this->sppcModule->getCollection()->
                addFieldToFilter('product_id', $product_id)->
                addFieldToFilter('store_id', 0)->getFirstItem();
        if (!empty($sppccollectiondata->getData())) {
            $data=$sppccollectiondata->getData();
            return $data;
        }
        return '';
    }
    public function getProductRateData($data, $countryId)
    {	
		 $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		 $logger = $objectManager->create('\Psr\Log\LoggerInterface');
        $is_perproduct_rate=NULL;
        if (isset($data['default_shipping_rate'])) {
			if($data['default_shipping_rate']==0){
				$is_perproduct_rate=NULL;
			}else{
				$is_perproduct_rate =(float)$data['default_shipping_rate'];
				$logger->info('second Test: '.$is_perproduct_rate);
			}
        }
        if (isset($data['countries_rate_data']) && $this->getEnableCountrySelection()) {
            $countryArray = json_decode($data['countries_rate_data'], true);
            if (array_key_exists($countryId, $countryArray)) {
                $is_perproduct_rate = (float)$countryArray[$countryId];
				$logger->info('Third Test: '.$is_perproduct_rate);
            }
        }
        return $is_perproduct_rate;
    }
    public function getEnableCountrySelection()
    {
        return  $this->getConfigData('enable_country_selection');
    }
}