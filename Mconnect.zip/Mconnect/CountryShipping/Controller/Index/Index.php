<?php
namespace Mconnect\CountryShipping\Controller\Index;

use \Magento\Checkout\Model\Session;
use Mconnect\CountryShipping\Model\Countryshipping;
use \Magento\Framework\Controller\Result\JsonFactory;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Catalog\Model\Product;
use Magento\GroupedProduct\Model\Product\Type\Grouped;
use Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable;
use Magento\Bundle\Model\Product\Type;
use Magento\Store\Model\StoreManagerInterface;

class Index extends \Magento\Framework\App\Action\Action
{
    
    protected $session;
    protected $sppcModule;
    protected $resultJsonFactory;
    protected $scopeConfig;
    protected $productModule;
    protected $groupedProductModule;
    protected $configurableProductModule;
    protected $typeProductModule;
    protected $quoteRepository;
    protected $storeManager;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        Session $session,
        Countryshipping $sppcModule,
        JsonFactory $resultJsonFactory,
        ScopeConfigInterface $scopeConfigObject,
        Product $productModule,
        Grouped $groupedProductModule,
        Configurable $configurableProductModule,
        Type $typeProductModule,
        StoreManagerInterface $storeManager,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
    ) {
    
        $this->session = $session;
        $this->sppcModule  = $sppcModule;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->scopeConfig  = $scopeConfigObject;
        $this->productModule  = $productModule;
        $this->groupedProductModule  = $groupedProductModule;
        $this->configurableProductModule = $configurableProductModule;
        $this->typeProductModule =$typeProductModule;
        $this->quoteRepository = $quoteRepository;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    public function execute()
    {
    
        $productData=[];
        $quoteItemDate=[];
        $restricted=0;
        $productPopupdata='';
        $lastProductType='';
        $result = $this->resultJsonFactory->create();
        if ($this->getEnableCountryRestriction()) {
            $countryId=$this->getRequest()->getParam("countryId");
            $shippingmethodcode=$this->getRequest()->getParam("shippingmethodcode");
            
            if ($this->getRequest()->isAjax() && $shippingmethodcode=='mconnectship' && !empty($countryId)) {
                if (!empty($this->session->getQuote()->getAllItems())) {
                    $cartquote=$this->quoteRepository->get($this->session->getQuote()->getId());
                    
                    foreach ($this->session->getQuote()->getAllItems() as $item) {
                        $current_product_restricted=0;
                        $productId=$item->getProductId();
                        
                        $product      = $this->productModule->load($productId);
                        $type_id = $product->getTypeId();
                        if (($item->getIsVirtual() ||
                            $type_id == 'virtual' ||
                            $type_id == 'configurable' ||
                            $type_id == 'downloadable' ||
                            $type_id == 'grouped' ||
                            $type_id == 'bundle')) {
                            $isChidrenQty = true;
                            $lastProductType = $product->getTypeId();
                            continue;
                        }
                        
                        $data=$this->getSppcCollectionData($productId, $this->getStoreId());
                        
                        if (isset($data['restricted_countries'])) {
                            $countryArray = explode(",", $data['restricted_countries']);
                            if (array_search($countryId, $countryArray)!== false) {
                                $restricted=1;
                                $productData[]=$productId;
                                $current_product_restricted=1;
                                if ($item->getParentItemId()) {
                                    $quoteItemDate[]=$item->getParentItemId();
                                } else {
                                    $quoteItemDate[]=$item->getId();
                                }
                            }
                        }
                        if ($product->getTypeId() == "simple") {
                            if ($item->getParentItemId()) {
                                $quoteItem = $cartquote->getItemById($item->getParentItemId());
                                $parentIds=$quoteItem->getProductId();
                            } else {
                                $parentIdstemp = $this->groupedProductModule->
                                getParentIdsByChild((int)$product->getId());
                                if (isset($parentIdstemp[0])) {
                                    $parentIds =$parentIdstemp[0];
                                }
                            }
                            
                            if (isset($parentIds) && !empty($parentIds)) {
                                    $parent = $this->productModule->load($parentIds);
                                    $parent_data=$this->getSppcCollectionData($parentIds, $this->getStoreId());
                                if (isset($parent_data['restricted_countries'])) {
                                    $countryArray = explode(",", $parent_data['restricted_countries']);
                                    if (array_search($countryId, $countryArray)!== false) {
                                        $restricted=1;
                                        $productData[]=$parentIds;
                                        if ($item->getParentItemId()) {
                                            $quoteItemDate[]=$item->getParentItemId();
                                        } else {
                                            $quoteItemDate[]=$item->getId();
                                        }
                                    }
                                }
                                    
                                if ($current_product_restricted==1) {
                                    $productData[]=$parentIds;
                                }
                            }
                        }
                        $lastProductType = "";
                    }
                }
            }
            if ($restricted==1) {
                $productData=array_values(array_unique($productData));
                $quoteItemDate=array_values(array_unique($quoteItemDate));
                $productPopupdata = $this->_view->getLayout()->createBlock(
                    '\Magento\Checkout\Block\Cart\Item\Renderer',
                    'spppc_index',
                    ['data' => ['productData' =>$productData,
                                "quoteItemDate"=>$quoteItemDate,
                                'QuoteId'=>$this->session->getQuote()->getId() ]]
                )->setTemplate(
                    "Mconnect_CountryShipping::countryshipping/products.phtml"
                )->toHtml();
            }
        }
        
        $returndata=['restricted'=>$restricted,
                    "productId"=>$productData,
                    "quoteItemDate"=>$quoteItemDate,
                    'productPopupdata'=>$productPopupdata
                    ];
        
        return $result->setData($returndata);
    }
    private function getEnableCountryRestriction()
    {
        return  $this->scopeConfig->getValue(
            'carriers/mconnectship/enable_country_restriction',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getStoreId()
        );
    }
    private function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }
    private function getSppcCollectionData($product_id, $store_id)
    {
         
        $sppccollectiondata = $this->sppcModule->getCollection()->
                addFieldToFilter('product_id', $product_id)->
                addFieldToFilter('store_id', $store_id)->getFirstItem();
        
        if (!empty($sppccollectiondata->getData())) {
            $data=$sppccollectiondata->getData();
            return $data;
        }
        $sppccollectiondata = $this->sppcModule->getCollection()->
                addFieldToFilter('product_id', $product_id)->
                addFieldToFilter('store_id', 0)->getFirstItem();
        if (!empty($sppccollectiondata->getData())) {
            $data=$sppccollectiondata->getData();
            return $data;
        }
        return '';
    }
}
