/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            proceedToCheckout:'Mconnect_CountryShipping/js/proceedtocheckout'
        }
    },
    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'Mconnect_CountryShipping/js/view/shipping': true
            },
            'Magento_Checkout/js/view/cart/shipping-rates': {
                'Mconnect_CountryShipping/js/view/cart/shipping-rates': true
            }
            
        } 
    }
};
