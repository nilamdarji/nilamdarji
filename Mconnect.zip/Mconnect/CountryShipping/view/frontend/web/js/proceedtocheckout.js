/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
        'jquery',
        'Magento_Customer/js/model/authentication-popup',
        'Magento_Customer/js/customer-data',
		'Magento_Checkout/js/model/quote',
		'ko',
		],
	function ($, authenticationPopup, customerData,quote,ko) {
        'use strict';

         return function (config, element) {
            $(element).click(function (event) {
				var countryId = $('select[name="country_id"]').val();
				
				if(quote.shippingMethod()!=null  && getSPPPCEnableorNot!=0 && quote.shippingMethod()['method_code']=='mconnectship') {
					var viewModel = {
						countryId : countryId, 
						shippingmethodcode : quote.shippingMethod()['method_code'],
                        shippingcarriercode : quote.shippingMethod()['carrier_code'],
					};
					 var data = ko.toJS(viewModel);
					$("#restrictedProduct_loader").show();
					$.getJSON(spppcAjaxURL, data, function(returnedData) {
						if(returnedData.restricted==1) {
							$("#restrictedProduct_popup").html(returnedData.productPopupdata);
							$('#restrictedProduct_popup').modal('openModal');
							
						}else{
							$("#restrictedProduct_loader").hide();
							var cart = customerData.get('cart'),
								customer = customerData.get('customer');

								event.preventDefault();

								if (!customer().firstname && cart().isGuestCheckoutAllowed === false) {
									authenticationPopup.showModal();

									return false;
								}
								location.href = config.checkoutUrl;
						}
						$("#restrictedProduct_loader").hide();
						
					});
                     
					
				}else{
					
					var cart = customerData.get('cart'),
                    customer = customerData.get('customer');

					event.preventDefault();

					if (!customer().firstname && cart().isGuestCheckoutAllowed === false) {
						authenticationPopup.showModal();

						return false;
					}
					location.href = config.checkoutUrl;
				}
			});

        }; 
    }
);
