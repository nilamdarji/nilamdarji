/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
define(
[
    'jquery',
    'ko',
    'underscore',
    'uiComponent',
    'Magento_Checkout/js/model/shipping-service',
    'Magento_Catalog/js/price-utils',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/action/select-shipping-method',
    'Magento_Checkout/js/checkout-data'
],
function (
    $,
    ko,
    _,
    Component,
    shippingService,
    priceUtils,
    quote,
    selectShippingMethodAction,
    checkoutData
) {
    'use strict';
    var mixin = {
        selectedShippingMethod: ko.computed(function () {
             $(".mcsnotice").html("").hide();
            if(quote.shippingMethod() && getSPPPCEnableorNot!=0 && quote.shippingMethod()['method_code']=='mconnectship') {
                var countryId = $('select[name="country_id"]').val();
                var viewModel = {
                    countryId : countryId, 
                    shippingmethodcode : quote.shippingMethod()['method_code'],
                    shippingcarriercode : quote.shippingMethod()['carrier_code'],
                };
                var data = ko.toJS(viewModel);
                $("#restrictedProduct_loader").show();
                $.getJSON(spppcAjaxURL, data, function(returnedData) {
                    if(returnedData.restricted==1) {
                        var msg="* This product cannot be shipped to your country using selected method.";
                        $(".mcsnotice").html("").hide();
                        returnedData.quoteItemDate.forEach(function(value1) {
                            $(".mcsnotice_item_id-"+value1 ).each(function() {
                              $( this ).html(msg).show();
                            });
                        });
                        
                    } else {
                            $(".mcsnotice").html("").hide();
                    }
                    $("#restrictedProduct_loader").hide();
                    
                });
                
            }
            return quote.shippingMethod() ?
                    quote.shippingMethod()['carrier_code'] + '_' + quote.shippingMethod()['method_code'] :
                    null;
        })
    };
    return function (target) {
        return target.extend(mixin);        
    };
        
    
});
