/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*global define*/
define(
    [
        'jquery',
        'underscore',
        'Magento_Ui/js/form/form',
        'ko',
        'Magento_Customer/js/model/customer',
        'Magento_Customer/js/model/address-list',
        'Magento_Checkout/js/model/address-converter',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/action/create-shipping-address',
        'Magento_Checkout/js/action/select-shipping-address',
        'Magento_Checkout/js/model/shipping-rates-validator',
        'Magento_Checkout/js/model/shipping-address/form-popup-state',
        'Magento_Checkout/js/model/shipping-service',
        'Magento_Checkout/js/action/select-shipping-method',
        'Magento_Checkout/js/model/shipping-rate-registry',
        'Magento_Checkout/js/action/set-shipping-information',
        'Magento_Checkout/js/model/step-navigator',
        'Magento_Ui/js/modal/modal',
        'Magento_Checkout/js/model/checkout-data-resolver',
        'Magento_Checkout/js/checkout-data',
        'uiRegistry',
        'mage/translate',
        'Magento_Checkout/js/model/shipping-rate-service'
    ],
    function (
        $,
        _,
        Component,
        ko,
        customer,
        addressList,
        addressConverter,
        quote,
        createShippingAddress,
        selectShippingAddress,
        shippingRatesValidator,
        formPopUpState,
        shippingService,
        selectShippingMethodAction,
        rateRegistry,
        setShippingInformationAction,
        stepNavigator,
        modal,
        checkoutDataResolver,
        checkoutData,
        registry,
        $t
    ) {
        'use strict';

        
            /**
             * Set shipping information handler
             */
            var mixin = {     
                setShippingInformation: function () {
                    
                    if (this.validateShippingInformation()) {
                        //console.log(getSPPPCEnableorNot);  
                        if(getSPPPCEnableorNot!=0 && quote.shippingMethod().method_code=='mconnectship') {
                            var viewModel = {
                                countryId : quote.shippingAddress().countryId,
                                shippingmethodcode : quote.shippingMethod().method_code,
                                shippingcarriercode : quote.shippingMethod().carrier_code,
                            };
                            var data = ko.toJS(viewModel);
                            var temp=this;
                            this.isLoading(true);
                            $.getJSON(spppcAjaxURL, data, function(returnedData) {
                                
                                if(returnedData.restricted==1) {	
                                    $("#restrictedProduct_popup").html(returnedData.productPopupdata);
                                    $('#restrictedProduct_popup').modal('openModal');
                                    temp.isLoading(false);
                                } else {
                                    temp.isLoading(false);
                                    setShippingInformationAction().done(
                                        function () {
                                            stepNavigator.next();
                                        }
                                    );
                                }							
                            });
                        } else {
                            setShippingInformationAction().done(
                                        function () {
                                            stepNavigator.next();
                                        }
                                    );
                        }
                        
                    }
                }

            };
            return function (target) {
                return target.extend(mixin);        
            };
       
    });
