<?php

namespace Mconnect\CountryShipping\Observer;

use \Magento\Framework\Event\Observer;
use \Magento\Framework\Event\ObserverInterface;
use Mconnect\CountryShipping\Model\CountryshippingFactory;
use Mconnect\CountryShipping\Model\ResourceModel\Countryshipping\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Registry;

class CatalogProductSaveBefore implements ObserverInterface
{
    
    protected $scopeConfigObject;
    
    protected $storeManager;
        
    protected $request;
        
    protected $sppcmodel;
        
    protected $sppccollection;
        
    protected $registry;
    
    public function __construct(
        \Magento\Catalog\Helper\Product $catalogProductHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigObject,
        \Magento\Framework\App\RequestInterface $request,
        CountryshippingFactory $sppcproduct,
        CollectionFactory $sppccollection,
        StoreManagerInterface $storeManager,
        Registry $registry
    ) {
            
        $this->catalogProductHelper = $catalogProductHelper;
        $this->scopeConfigObject = $scopeConfigObject;
        $this->storeManager = $storeManager;
        $this->request = $request;
        $this->sppcmodel = $sppcproduct;
        $this->sppccollection = $sppccollection;
        $this->registry = $registry;
    }
    
    public function execute(Observer $observer)
    {
        
          $currentProduct=$this->registry->registry('current_product');
          $currentProductId=$currentProduct->getId();
          $product = $observer->getProduct();
          $productId = $product->getId();
          $postData = $this->request->getPostValue();
            
        if ($productId!=$currentProductId) {
            return;
        }
            $store_id=$this->storeManager->getStore()->getId();
            $sppccollection = $this->sppccollection->create();
            $sppccollection->addFieldToFilter('product_id', $productId);
            $sppccollection->addFieldToFilter('store_id', $store_id);
            $availableSppc = $sppccollection->getColumnValues('sppc_id');
            $data = [];
            $default_shipping_rate='';
            $restricted_countries='';
        if (isset($postData['country']) &&
            !empty($postData['country']) &&
            isset($postData['country_shipping_rate']) &&
            !empty($postData['country_shipping_rate'])) {
            foreach ($postData['country'] as $k => $country) {
                $data[$country] = $postData['country_shipping_rate'][$k];
            }
        }
            $data=json_encode($data);
            
        if (isset($postData['product']['default_shipping_rate']) &&
        !empty($postData['product']['default_shipping_rate'])) {
            $default_shipping_rate=$postData['product']['default_shipping_rate'];
        }
        if (isset($postData['product']['restricted_countries']) &&
        !empty($postData['product']['restricted_countries'])) {
            $restricted_countries=$postData['product']['restricted_countries'];
        }
        if ($restricted_countries!='' || $default_shipping_rate!='' || !empty($data)) {
            if (!empty($sppccollection)) {
                $id=$sppccollection->getFirstItem()->getSppcId();
                $sppcmodel = $this->sppcmodel->create();
                $sppcmodel->load($id);
                $sppcmodel->setProductId($productId);
                $sppcmodel->setDefaultShippingRate($default_shipping_rate);
                $sppcmodel->setCountriesRateData($data);
                $sppcmodel->setRestrictedCountries($restricted_countries);
                $sppcmodel->setStoreId($this->storeManager->getStore()->getId());
                $sppcmodel->save();
            } else {
                $sppcmodel = $this->sppcmodel->create();
                $sppcmodel->load(null);
                $sppcmodel->setProductId($productId);
                $sppcmodel->setDefaultShippingRate($default_shipping_rate);
                $sppcmodel->setCountriesRateData($data);
                $sppcmodel->setRestrictedCountries($restricted_countries);
                $sppcmodel->setStoreId($this->storeManager->getStore()->getId());
                $sppcmodel->save();
            }
        }
    }
}
