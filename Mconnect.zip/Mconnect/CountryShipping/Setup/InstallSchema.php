<?php namespace Mconnect\CountryShipping\Setup;
 
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
 
class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
 
        /**
         * Create table 'shippingperproduct_countries'
         */
 
        $tableName = $installer->getTable('shippingperproduct_countries');
        $tableComment = 'table for shipping per product per countries module';
        $columns = [
            'sppc_id' => [
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'comment' => 'hipping per product per countries Id',
            ],
            'product_id' => [
                'type' => Table::TYPE_INTEGER,
                'size' => null,
               'options' => ['unsigned' => true, 'nullable' => false],
                'comment' => 'product id',
            ],
            'default_shipping_rate' => [
                'type' => Table::TYPE_DECIMAL,
                'size' => '12,4',
               'options' => ['unsigned' => true, 'nullable' => false],
               'comment' => 'product default shipping rate',
            ],
            'countries_rate_data' => [
                'type' => Table::TYPE_TEXT,
                'size' => 2048,
                'options' => ['nullable' => false, 'default' => ''],
                'comment' => 'countries data with price',
            ],
            'restricted_countries' => [
                'type' => Table::TYPE_TEXT,
                'size' => 2048,
                'options' => ['nullable' => false, 'default' => ''],
                'comment' => 'restricted countries data',
            ],
        ];
 
        $indexes =  [
            // No index for this table
        ];
 
        $foreignKeys = [
            // No foreign keys for this table
        ];
 
        /**
         *  We can use the parameters above to create our table
         */
 
        // Table creation
        $table = $installer->getConnection()->newTable($tableName);
 
        // Columns creation
        foreach ($columns as $name => $values) {
            $table->addColumn(
                $name,
                $values['type'],
                $values['size'],
                $values['options'],
                $values['comment']
            );
        }
 
        // Indexes creation
        foreach ($indexes as $index) {
            $table->addIndex(
                $installer->getIdxName($tableName, [$index]),
                [$index]
            );
        }
 
        // Foreign keys creation
        foreach ($foreignKeys as $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column, $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column,
                $foreignKey['ref_table'],
                $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }
 
        // Table comment
        $table->setComment($tableComment);
 
        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);
 
        // End Setup
        $installer->endSetup();
    }
}
