<?php namespace Mconnect\CountryShipping\Setup;
 
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
 
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrades DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
 
        // Action to do if module version is less than 1.0.0.0
        if (version_compare($context->getVersion(), '1.1.0') < 0) {
 
            /**
             * Add New Store id column in  shippingperproduct_countries table
             */
 
            $tableName = $installer->getTable('shippingperproduct_countries');
            
            if ($setup->getConnection()->isTableExists($tableName) == true) {
                // Declare data
                $columns = [
                    'store_id' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,
                        'options' => ['unsigned' => true, 'nullable' => false],
                        'comment' => 'Store id',
                    ],
                ];

                $connection = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }
            }
        }
 
        $installer->endSetup();
    }
}
