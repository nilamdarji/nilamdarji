<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mconnect\Ajaxproductscroller\Controller\Category;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */

class View extends \Magento\Catalog\Controller\Category\View
{

    /**
     * Catalog Layer Resolver
     *
     * @var Resolver
     */
    private $layerResolver;
    
    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Catalog\Model\Design $catalogDesign
     * @param \Magento\Catalog\Model\Session $catalogSession
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\CatalogUrlRewrite\Model\CategoryUrlPathGenerator $categoryUrlPathGenerator
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Catalog\Model\Design $catalogDesign,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\CatalogUrlRewrite\Model\CategoryUrlPathGenerator $categoryUrlPathGenerator,
        PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository
    ) {
        parent::__construct(
            $context,
            $catalogDesign,
            $catalogSession,
            $coreRegistry,
            $storeManager,
            $categoryUrlPathGenerator,
            $resultPageFactory,
            $resultForwardFactory,
            $layerResolver,
            $categoryRepository
        );
        $this->layerResolver = $layerResolver;
    }
    
    /**
     * Category view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
     
    public function execute()
    {
        $ajax = $this->getRequest()->getParam('ajax');
        
        if (!$ajax) {
            return parent::execute();
        }
        
        if ($this->_request->getParam(\Magento\Framework\App\ActionInterface::PARAM_NAME_URL_ENCODED)) {
            return $this->resultRedirectFactory->create()->setUrl($this->_redirect->getRedirectUrl());
        }
        $ajx_category = $this->_initCategory();
        
        if ($ajx_category) {
            $this->layerResolver->create(Resolver::CATALOG_LAYER_CATEGORY);
            $ajx_settings = $this->_catalogDesign->getDesignSettings($ajx_category);

            if ($ajx_settings->getCustomDesign()) {
                $this->_catalogDesign->applyCustomDesign($ajx_settings->getCustomDesign());
            }

            $this->_catalogSession->setLastViewedCategoryId($ajx_category->getId());

            $page = $this->resultPageFactory->create();
            
            if ($ajx_settings->getPageLayout()) {
                $page->getConfig()->setPageLayout($ajx_settings->getPageLayout());
            }
            if ($ajx_category->getIsAnchor()) {
                $type = $ajx_category->hasChildren() ? 'layered' : 'layered_without_children';
            } else {
                $type = $ajx_category->hasChildren() ? 'default' : 'default_without_children';
            }

            if (!$ajx_category->hasChildren()) {
                $parentType = strtok($type, '_');
                $page->addPageLayoutHandles(['type' => $parentType]);
            }
            $page->addPageLayoutHandles(['type' => $type, 'id' => $ajx_category->getId()]);

            $layoutUpdates = $ajx_settings->getLayoutUpdates();
            if ($layoutUpdates && is_array($layoutUpdates)) {
                foreach ($layoutUpdates as $layoutUpdate) {
                    $page->addUpdate($layoutUpdate);
                }
            }

            $page->getConfig()->addBodyClass('page-products')
                ->addBodyClass('categorypath-' . $this->categoryUrlPathGenerator->getUrlPath($ajx_category))
                ->addBodyClass('category-' . $ajx_category->getUrlKey());
                
            if ($ajax) {
                $resultJson = $this->getProductJson();
                return $resultJson;
            }
                
            return $page;
        } elseif (!$this->getResponse()->isRedirect()) {
            return $this->resultForwardFactory->create()->forward('noroute');
        }
    }
    
    private function getProductJson()
    {
        $this->_view->loadLayout();
        $layout = $this->_view->getLayout();
        $block = $layout->getBlock('category.products.list')
                      ->setTemplate('Magento_Catalog::product/list.phtml');
        $responseData = [
          'errors' => false,
          'productdata' => $block->toHtml(),
        ];
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($responseData);
        return $resultJson;
    }
}
