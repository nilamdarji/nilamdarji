<?php
namespace Mconnect\Ajaxproductscroller\Controller\Result;

use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResourceConnection;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Search\Model\QueryFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\CatalogSearch\Controller\Result\Index
{
    /**
     * @var QueryFactory
     */
    private $queryFactory;

    /**
     * Catalog Layer Resolver
     *
     * @var Resolver
     */
    private $layerResolver;
      
    /**
     * @param Context $context
     * @param Session $catalogSession
     * @param StoreManagerInterface $storeManager
     * @param QueryFactory $queryFactory
     * @param Resolver $layerResolver
     */
    public function __construct(
        Context $context,
        Session $catalogSession,
        StoreManagerInterface $storeManager,
        QueryFactory $queryFactory,
        Resolver $layerResolver,
        \Magento\CatalogSearch\Helper\Data $catalogSearchHelperData,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context, $catalogSession, $storeManager, $queryFactory, $layerResolver);
        $this->queryFactory = $queryFactory;
        $this->layerResolver = $layerResolver;
        $this->catalogSearchHelperData = $catalogSearchHelperData;
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Display search result
     *
     * @return void
     */
    public function execute()
    {
        /*-------------------MCS CUSTOM CODE FOR AJAX-----------------*/
        $ajax = $this->getRequest()->getParam('ajax');
        $this->layerResolver->create(Resolver::CATALOG_LAYER_SEARCH);
        $query = $this->queryFactory->get();

        $query->setStoreId($this->_storeManager->getStore()->getId());
        if ($query->getQueryText() != '') {
            if ($this->catalogSearchHelperData->isMinQueryLength()) {
                $query->setId(0)->setIsActive(1)->setIsProcessed(1);
            } else {
                $query->saveIncrementalPopularity();

                if ($query->getRedirect()) {
                    $this->getResponse()->setRedirect($query->getRedirect());
                    return;
                }
            }

            $this->catalogSearchHelperData->checkNotes();
            $this->_view->loadLayout();
            $this->_view->renderLayout();
            /*-------------------MCS CUSTOM CODE FOR AJAX-----------------*/
            if ($ajax) {
                $resultPage = $this->resultPageFactory->create();
                $block = $resultPage ->getLayout()
                ->getBlock('search_result_list')
                ->setTemplate('Magento_Catalog::product/list.phtml')
                ->toHtml();
                $responseData = [
                'errors' => false,
                'productdata' => $block,
                ];
            
                $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                $resultJson->setData($responseData);
                return $resultJson;
            }
        } else {
            $this->getResponse()->setRedirect($this->_redirect->getRedirectUrl());
        }
    }
}
