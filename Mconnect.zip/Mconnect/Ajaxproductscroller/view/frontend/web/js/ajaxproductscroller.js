define(
    [
            'jquery',
            'Magento_Ui/js/modal/modal',
        ],
    function (
        $,
        modal
    ) {
        "use strict";
        return {
            ajaxproductscrollerData:function (pagecount, pageUrl, loaderMethod, ppp) {
                                
                jQuery('#loader-container').hide();
                jQuery('#notMoteLoad').hide();
                var p=2;
                var callSet=0;

                            
                function last_msg_funtion()
                {
                    if (p<=pagecount) {
                        jQuery('#loader-container').show();
                        
                        var getUrl=pageUrl+"="+p+"&ajax=1";
                                
                        jQuery.ajax({
                            url: getUrl,
                            type: 'get',
                            dataType: 'json',
                            }).done(function (data ) {
                                
                            var response = jQuery('<ol />').html(data.productdata).find('.product-items').html();
                            jQuery(".product-items li:last").after(response);
							var htmlObject = $('.product-items li').slice(-ppp);
								
								htmlObject.find('[data-role=tocart-form], .form.map.checkout')
                                        .attr('data-mage-init', JSON.stringify({'catalogAddToCart': {}}));
								htmlObject.trigger('contentUpdated');                            
                                    
                            p++;
                            callSet=0;
                            jQuery('#loader-container').hide();
                            
                            if (loaderMethod==0) {
                             jQuery('#mcs_show_more').show();
                            }
                                    
                            if (p>pagecount && loaderMethod==0) {
                                jQuery('#notMoteLoad').show();
                                jQuery('#mcs_show_more').hide();
                            }
                            
                        });
                        } else {
                        jQuery('#notMoteLoad').show();
                        }
                }
                
                if (loaderMethod==1) {
                    jQuery(window).scroll(function () {
            
                    
                        var wST=parseInt(jQuery(window).scrollTop());
                        var dH=parseInt(jQuery('.main').height());
                        var wH=parseInt(jQuery(window).height());
                        
                        var FC=dH-wH;
                    
                        if (wST > FC) {
                            if (callSet==0) {
                            callSet=1;
                            last_msg_funtion();
                            }
                        }
                    
                    });
                }

                    /*---------------------register form open------------------------*/
                            
                $(document).on('click','#mcs_show_more',function (event) {
                    last_msg_funtion();
                    jQuery('#mcs_show_more').hide();
                });
                
            
            }
            
        }
        
    
    }
);
            
