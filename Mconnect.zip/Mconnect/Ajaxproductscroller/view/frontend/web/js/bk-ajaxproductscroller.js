define(
        [
            'jquery',
            'Magento_Ui/js/modal/modal'						
        ],
        function(
            $,
            modal
			
        ) {
		"use strict";
		return {
			
			ajaxproductscrollerData:function(pagecount,	pageUrl, loaderMethod){
			
			
			jQuery('#loader-container').hide();	
			jQuery('#notMoteLoad').hide();
			var p=2;
			var callSet=0; 

						
			function last_msg_funtion(){
				if(p<=pagecount){
					
					jQuery('#loader-container').show();	
					
					var getUrl=pageUrl+"="+p+"&ajax=1";
							
					jQuery.ajax({
						url: getUrl,  
					//  data:{ajax:1},
						type: 'get',
						dataType: 'json',
						}).done(function(data){	
					//	console.log(data);
			
						var htmlObject=jQuery(".products.wrapper:last").after(data.productdata);
						
						htmlObject.find('[data-role=tocart-form], .form.map.checkout')
									.attr('data-mage-init', JSON.stringify({'catalogAddToCart': {}}));				
									htmlObject.trigger('contentUpdated');						
						//console.log('test');
									
						p++;
						callSet=0;
						jQuery('#loader-container').hide();
						
						if(loaderMethod==0){
						 jQuery('#mcs_show_more').show();
						}
								
						if(p>pagecount && loaderMethod==0){
							jQuery('#notMoteLoad').show();
							jQuery('#mcs_show_more').hide();
						}
						
					});
					
						
					}else{				
					jQuery('#notMoteLoad').show();	
					} 
			}
			
			if(loaderMethod==1){
				jQuery(window).scroll(function(){			
		
				//  console.log(jQuery(window).scrollTop());	
				//	console.log(jQuery(document).height());	
				//	console.log(jQuery(window).height());
					
					var wST=parseInt(jQuery(window).scrollTop());
				  //var dH=parseInt(jQuery(document).height());
					var dH=parseInt(jQuery('.main').height());
					var wH=parseInt(jQuery(window).height());
					
					var FC=dH-wH;
					
					//console.log(wST);	
					//console.log(FC);	
					//console.log(wH);
				
					if (wST > FC){
						if(callSet==0){
						callSet=1;
						last_msg_funtion();
						
						}
					}	
				
				});	
				
			}

			/*---------------------register form open------------------------*/
					
			$(document).on('click','#mcs_show_more',function(event){				
				last_msg_funtion();	
				jQuery('#mcs_show_more').hide();
			}); 
				
				
				
			
			}
			
		}
			
});		
			