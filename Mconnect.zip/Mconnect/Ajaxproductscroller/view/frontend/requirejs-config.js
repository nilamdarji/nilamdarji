
var config = {
    map: {
        '*': {			
			ajaxproductscroller: 'Mconnect_Ajaxproductscroller/js/ajaxproductscroller',			
        }
    }
};