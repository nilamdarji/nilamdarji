<?php
namespace Mconnect\Ajaxproductscroller\Model\Config\Source;

class Loadingmethod implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => __('Button Click')],
            ['value' => '1', 'label' => __('Mouse Scroll')],
			
        ];
    }
}
