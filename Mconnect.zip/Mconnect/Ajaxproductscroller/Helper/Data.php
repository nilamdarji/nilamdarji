<?php
namespace Mconnect\Ajaxproductscroller\Helper;

use Magento\Store\Model\ScopeInterface;

/**
 * Ajaxproductscroller config data helper
 * @package Mconnect\Ajaxproductscroller\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	
	public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        $this->request = $context->getRequest();
        parent::__construct($context);
    }
    
		
	/*-----------------------------Loader Method------------------------*/
	
	const XML_PATH_APS_LOADER_METHOD = 'mconnect_ajaxproductscroller/general/loader_method';	
	
	/**
     * getLoaderMethod     
     */
    public function getLoaderMethod($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_APS_LOADER_METHOD,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	
	/*-----------------------------Loader Text------------------------*/
	
	const XML_PATH_APS_LOADER_TEXT = 'mconnect_ajaxproductscroller/general/loader_text';	
	
	/**
     * getLoaderMethod     
     */
    public function getLoaderText($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_APS_LOADER_TEXT,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	
	/*-----------------------------Loader Image------------------------*/
	
	const XML_PATH_APS_LOADER_IMAGE = 'mconnect_ajaxproductscroller/general/loader_image';	
	
	/**
     * getLoaderMethod     
     */
    public function getLoaderImage($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_APS_LOADER_IMAGE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	
	 /*-----------------------------get PagePerProducts------------------------*/
    
    const XML_PATH_GPP = 'catalog/frontend/grid_per_page';
    const XML_PATH_LPP = 'catalog/frontend/list_per_page';
    
    /**
     * getLoaderMethod
     */
    public function getProductsPerPage($storeId = null)
    {
        if ($this->request->getParam('product_list_mode')) {
            if ($this->request->getParam('product_list_mode')=='list') {
                return $this->scopeConfig->getValue(
                    self::XML_PATH_LPP,
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                );
            } else {
                return $this->scopeConfig->getValue(
                    self::XML_PATH_GPP,
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                );
            }
        } else {
            return $this->scopeConfig->getValue(
                self::XML_PATH_GPP,
                ScopeInterface::SCOPE_STORE,
                $storeId
            );
        }
    }
	
	
}
