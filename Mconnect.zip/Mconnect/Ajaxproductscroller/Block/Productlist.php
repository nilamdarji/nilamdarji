<?php
namespace Mconnect\Ajaxproductscroller\Block;

class Productlist extends \Magento\Framework\View\Element\Template
{

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\ObjectManagerInterface $objectmanager
    ) {
        parent::__construct($context);
        $this->urlInterface = $context->getUrlBuilder();
        $this->_objectManager = $objectmanager;
    }
    
    public function getObjectManager()
    {
        return $this->_objectManager;
    }

    public function getListProduct()
    {
        $request = $this->getRequest()->getFullActionName();
        if($request=='catalogsearch_result_index') {
             $block = $this->getLayout()->getBlock('search_result_list');
        }else{
            $block = $this->getLayout()->getBlock('category.products.list');
        }
        $productCollection = $block->getLoadedProductCollection();
        return $productCollection;
    }
    
    public function getPageUrl()
    {
        return $this->urlInterface->getCurrentUrl();
    }
}
