<?php
namespace Mconnect\Giftcard\Model\Product\Type;

class Giftcard extends \Magento\Catalog\Model\Product\Type\AbstractType
{
    const TYPE_CODE = 'giftcardproduct';

    /**
     * Check is virtual product
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return bool
     */
     public function isVirtual($product)
     {
         return true;
     }

    /**
     * Check that product of this type has weight
     *
     * @return bool
     */
     public function hasWeight()
     {
         return false;
     }


    /**
     * Delete data specific for Simple product type
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return void
     */
    public function deleteTypeSpecificData(\Magento\Catalog\Model\Product $product)
    {
    }
}
