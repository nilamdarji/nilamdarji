
var config = {
    map: {
        '*': {
            giftcard:'Mconnect_Giftcard/js/giftcard'
        }
    },
    deps: [
          "Magento_Catalog/js/product-gallery",
       "Magento_Catalog/catalog/base-image-uploader"
    ]
};