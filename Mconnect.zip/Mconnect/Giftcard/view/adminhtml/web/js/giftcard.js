require(
    [
    'jquery'
    ],
    function ($) {
        
    }
);

