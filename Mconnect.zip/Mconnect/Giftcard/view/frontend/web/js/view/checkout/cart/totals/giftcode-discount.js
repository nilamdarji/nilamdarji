define(
    [
        'Mconnect_Giftcard/js/view/checkout/summary/giftcode-discount'
    ],
    function (Component) {
        'use strict';
 
        return Component.extend({
 
            /**
             * @override
             */
            isDisplayed: function () {
                return true;
            }
        });
    }
);
