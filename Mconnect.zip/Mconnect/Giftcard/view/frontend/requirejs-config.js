
var config = {
    map: {
        '*': {
            giftcard: 'Mconnect_Giftcard/js/giftcard',
            giftcode: 'Mconnect_Giftcard/js/gift-codes'
        }
    }
};
