<?php
namespace Mconnect\Giftcard\Block\Adminhtml\Giftcode;

/**
 * Adminhtml Gift Code grid
 */
class Grid extends \Magento\Backend\Block\Widget\Grid
{
   
}
