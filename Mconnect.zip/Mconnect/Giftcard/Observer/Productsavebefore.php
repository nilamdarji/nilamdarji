<?php

namespace Mconnect\Giftcard\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class Productsavebefore implements ObserverInterface
{
    protected $giftData;

    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $_layout;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    protected $_request;
    /**
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\LayoutInterface $layout
     */
    public function __construct(
        \Mconnect\Giftcard\Helper\Data $giftData
    ) {
    
        $this->giftData = $giftData;
    }
    /**
     * Add order information into GA block to render on checkout success pages
     *
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        
        $product = $observer->getProduct();       
        if( $product->getData("gc_amounts") == NULL ){

         
              throw new \Magento\Framework\Exception\LocalizedException(
                        __('Unable to save ,please check gift card options section.')
                    );
         
        
    }
     if( $product->getData("gc_email_templates") == NULL ){
         throw new \Magento\Framework\Exception\LocalizedException(
                        __('Unable to save ,please check gift card options section.')
                    );

     }
    
 
    }
}
