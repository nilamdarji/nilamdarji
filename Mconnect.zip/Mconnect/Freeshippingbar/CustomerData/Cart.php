<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Mconnect\Freeshippingbar\CustomerData;

use Magento\Customer\CustomerData\SectionSourceInterface;
use Magento\Checkout\CustomerData\Cart as CoreCart;

/**
 * Cart source
 */
class Cart extends CoreCart
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $checkoutCart;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Url
     */
    protected $catalogUrl;

    /**
     * @var \Magento\Quote\Model\Quote|null
     */
    protected $quote = null;

    /**
     * @var \Magento\Checkout\Helper\Data
     */
    protected $checkoutHelper;

    /**
     * @var Magento\Checkout\CustomerData\ItemPoolInterface
     */
    protected $itemPoolInterface;

    /**
     * @var int|float
     */
    protected $summeryCount;

    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $layout;
    
    /**
     * @var \Mconnect\Freeshippingbar\Block\Freeshippingbar\Freeshipbar
     */
    protected $blockFreeship;
    
    protected $helper;

    /**
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Catalog\Model\ResourceModel\Url $catalogUrl
     * @param \Magento\Checkout\Model\Cart $checkoutCart
     * @param \Magento\Checkout\Helper\Data $checkoutHelper
     * @param Magento\Checkout\CustomerData\ItemPoolInterface $itemPoolInterface
     * @param \Magento\Framework\View\LayoutInterface $layout
     * @param array $data
     * @codeCoverageIgnore
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Catalog\Model\ResourceModel\Url $catalogUrl,
        \Magento\Checkout\Model\Cart $checkoutCart,
        \Magento\Checkout\Helper\Data $checkoutHelper,
        \Magento\Checkout\CustomerData\ItemPoolInterface $itemPoolInterface,
        \Magento\Framework\View\LayoutInterface $layout,
        \Mconnect\Freeshippingbar\Block\Freeshippingbar\Freeshipbar $blockFreeship,
        \Mconnect\Freeshippingbar\Helper\Data $helper,
        array $data = []
    ) {
        parent::__construct($checkoutSession, $catalogUrl, $checkoutCart, $checkoutHelper, $itemPoolInterface, $layout, $data);
        $this->blockFreeship = $blockFreeship;
        $this->helper = $helper;
    }

    /**
     * {@inheritdoc}
     */
    public function getSectionData()
    {
        $totals = $this->getQuote()->getTotals();
        
        return [
            'summary_count' => $this->getSummaryCount(),
            'subtotal' => isset($totals['subtotal'])
                ? $this->checkoutHelper->formatPrice($totals['subtotal']->getValue())
                : 0,
            'possible_onepage_checkout' => $this->isPossibleOnepageCheckout(),
            'items' => $this->getRecentItems(),
            'extra_actions' => $this->layout->createBlock('Magento\Catalog\Block\ShortcutButtons')->toHtml(),
            'isGuestCheckoutAllowed' => $this->isGuestCheckoutAllowed(),
            'website_id' => $this->getQuote()->getStore()->getWebsiteId(),
            'finalcost' => $this->blockFreeship->getFinalCost(),
            'freeshippingcost' => $this->helper->getFreeshippingCost(),
            'fontcolor' => $this->helper->getFontColor(),
            'bgcolor' => $this->helper->getBackgroundColor(),
            'fontsize' => $this->helper->getFontSize(),
			'grandTotal' => $this->blockFreeship->getGrandTotal(),
			'progressbar' => $this->blockFreeship->getProgressBar(),
			'awayfromdhippingprice' => $this->blockFreeship->getAwayFromShippingPrice(),
			'before_achieved_goal' => $this->helper->getConfig('mconnect_freeshippingbar/general/before_achieved_goal'),
			'after_achieved_goal' => $this->helper->getConfig('mconnect_freeshippingbar/general/after_achieved_goal'),
			'cart_loading_image' => $this->blockFreeship->getCartLoadingImage(),
        ];
    }
}
