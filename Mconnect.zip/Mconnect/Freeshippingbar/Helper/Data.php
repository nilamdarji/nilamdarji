<?php

namespace Mconnect\Freeshippingbar\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{   
    protected $mcsHelper;
    
	public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigObject,
        \Magento\Framework\App\Request\Http $request,
        \Mconnect\Freeshippingbar\Helper\McsHelper $mcsHelper
    ) {
        $this->_scopeConfig = $scopeConfigObject;
        $this->_request = $request;
        $this->mcsHelper = $mcsHelper;
    }
	
	
    const ISENABLED = 'mconnect_freeshippingbar/general/enable';
    const FREESHIPPINGBAR_COST = 'mconnect_freeshippingbar/general/shipping_bar';
    
    const DISPLAY = 'mconnect_freeshippingbar/display/page';
    
    const FREESHIPPINGBAR_FONT_COLOR = 'mconnect_freeshippingbar/design/font_color';
    const FREESHIPPINGBAR_BACKGROUND_COLOR = 'mconnect_freeshippingbar/design/bg_color';
    const FREESHIPPINGBAR_FONT_SIZE = 'mconnect_freeshippingbar/design/font_size';
	
	public function getFullActionName()
    {
        return $this->_request->getFullActionName();
    }
	
	public function isShowSideMinCart()
    {
		$fullActionName=$this->getFullActionName();
		if($fullActionName=='checkout_index_index' /* || $fullActionName=='checkout_cart_index' */){
		return false;	
		}
        return true;
    }
	
	public function isHomePageAction()
    {
		return $this->getFullActionName();		
    }
    
    public function getRequireJsTemplate()
    {
		if($this->isEnabled()) {
             $template =  'Mconnect_Freeshippingbar::require_js.phtml';
        }else{
             $template =  'Magento_Theme::page/js/require_js.phtml';
        }
        return $template;
                
    }
    
    public function getMiniCartTemplate()
    {
		if($this->isEnabled()) {
             $template =  'Mconnect_Freeshippingbar::cart/minicart.phtml';
        }else{
             $template =  'Magento_Checkout::cart/minicart.phtml';
        }
        return $template;
                
    }
    
    public function getCheckoutCartItemRender()
    {
		if($this->isEnabled()) {
             $template =  'Mconnect_Freeshippingbar/minicart/item/default';
        }else{
             $template =  'Magento_Checkout/minicart/item/default';
        }
        return $template;
                
    }
    public function getCheckoutCartTotalRender()
    {
		if($this->isEnabled()) {
             $template =  'Mconnect_Freeshippingbar/checkout/minicart/subtotal/totals';
        }else{
             $template =  'Magento_Checkout/minicart/subtotal/totals';
        }
        return $template;
                
    }
    public function getCheckoutCartTotalJsRender()
    {
		if($this->isEnabled()) {
             $template =  'Mconnect_Freeshippingbar/js/view/checkout/minicart/subtotal/totals';
        }else{
             $template =  'Magento_Checkout/js/view/checkout/minicart/subtotal/totals';
        }
        return $template;
                
    }
	
	public function getConfig($configPath)
    {
        return $this->_scopeConfig->getValue(
            $configPath,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    public function isEnabled(){
        if ($this->mcsHelper->checkLicenceKeyActivation() ) {
            return $this->_scopeConfig->getValue(
                self::ISENABLED,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );
        }else{
            return 0;
        }
    }
    
    public function getFreeshippingCost(){
        return $this->_scopeConfig->getValue(
            self::FREESHIPPINGBAR_COST,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    public function _display(){
        return $this->_scopeConfig->getValue(
            self::DISPLAY,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    public function getFontColor(){
        return $this->_scopeConfig->getValue(
            self::FREESHIPPINGBAR_FONT_COLOR,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    public function getBackgroundColor(){
        return $this->_scopeConfig->getValue(
            self::FREESHIPPINGBAR_BACKGROUND_COLOR,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    public function getFontSize(){
        return $this->_scopeConfig->getValue(
            self::FREESHIPPINGBAR_FONT_SIZE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	
	
	
}