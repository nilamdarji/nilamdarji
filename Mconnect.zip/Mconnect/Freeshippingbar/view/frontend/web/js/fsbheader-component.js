define([
    'jquery',
    'uiComponent',
    'ko',
    'Magento_Customer/js/customer-data'
], function ($, Component, ko, customerData) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Mconnect_Freeshippingbar/fsbheader'
            },
            initialize: function () {
                this._super();
                this.cart = customerData.get('cart');
            }
        });
    }
);