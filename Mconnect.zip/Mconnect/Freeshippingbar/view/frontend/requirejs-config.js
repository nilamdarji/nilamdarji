if(typeof shippingBarEnable != 'undefined' && shippingBarEnable=='1') {
    var config = {
        map: {
            '*': {
                sidebar:'Mconnect_Freeshippingbar/js/sidebar',
                catalogAddToCart:'Mconnect_Freeshippingbar/js/catalog-add-to-cart',
                'Magento_Checkout/js/view/minicart':'Mconnect_Freeshippingbar/js/view/minicart',			
                'Magento_Tax/js/view/checkout/minicart/subtotal/totals':
                'Mconnect_Freeshippingbar/js/view/checkout/minicart/subtotal/totals',
                'Magento_Checkout/template/minicart/content.html':'Mconnect_Freeshippingbar/template/minicart/content.html',
            }
        }
    };
}