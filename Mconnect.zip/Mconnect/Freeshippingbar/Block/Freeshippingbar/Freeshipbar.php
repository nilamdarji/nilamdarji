<?php

namespace Mconnect\Freeshippingbar\Block\Freeshippingbar;

use Magento\Framework\View\Element\Template;

class Freeshipbar extends Template
{
    public function __construct(
        Template\Context $context,
        \Mconnect\Freeshippingbar\Observer\CheckoutCartProductAddAfter $observer,
		\Mconnect\Freeshippingbar\Helper\Data $helper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $pageTitle = $this->getPageTitle();
        $this->pageConfig->getTitle()->set(__($pageTitle));
        $this->_observer = $observer;
		$this->_helper = $helper;
    }
    
    public function getFinalCost()
    {
        return $this->_observer->getPrice();
    }
	
	public function getGrandTotal()
    {
        return $this->_observer->getGrandTotal();
    }
	
	public function getProgressBar()
    {
		return $this->_observer->getProgressBar();
        
    }
	
	public function getAwayFromShippingPrice()
    {
		return $this->_observer->getAwayFromShippingPrice();
        
    }
    
    public function getAjaxPriceUrl()
    {
        return $this->getUrl("freeshippingbar/updateprice/updatedcartprice/");
    }
	
	public function getCartLoadingImage(){
		
		if(!empty($this->_helper->getConfig('mconnect_freeshippingbar/general/mcs_mini_cart_gif'))) {
						 $loadingImageUrl= \Magento\Framework\App\ObjectManager::getInstance()
						 ->get('Magento\Framework\UrlInterface')
						 ->getBaseUrl()
						 .'pub/media/mconnect/freeshippingbar/'.
						 $this->_helper->getConfig('mconnect_freeshippingbar/general/mcs_mini_cart_gif');
		} else {
			
			$loadingImageUrl = $this->getViewFileUrl('Mconnect_Freeshippingbar/images/build-website.gif');
		}

		return $loadingImageUrl;
        
    }
}