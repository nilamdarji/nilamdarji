<?php
namespace Mconnect\Partfinder\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'mconnect_partfinder'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('mconnect_partfinder')
        )->addColumn(
            'pf_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Part Finder Id'
        )->addColumn(
            'pf_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Part Finder Name'
        )->addColumn(
            'status',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            32,
            [],
            'Status'
        )->addColumn(
            'no_of_dropdowns',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => false],
            'No of Dropdowns'
        )->addColumn(
            'position',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Position of Part Finder'
        )->addColumn(
            'attr_set',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => true],
            'Attribute set ID'
        );
        $installer->getConnection()->createTable($table);      
      
		/**
         * Create table 'mconnect_pf_dropdowns'
         */
		
		$table = $installer->getConnection()
            ->newTable($installer->getTable('mconnect_pf_dropdowns'))
            ->addColumn(
                'dw_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Dropdown ID'
            )
            ->addColumn(
                'pf_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Part Finder ID'
            )
            ->addColumn(
                'pdw_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                'Parent Dropdown ID'
            )
            ->addColumn(
                'dw_name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Dropdown Name'
            )
            ->addColumn(
                'dw_sort',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [],
                'Sort Order'
            )
			->addColumn(
                'dw_range',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                'Is Value Range'
            )
			->addColumn(
                'position',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                'Position'
            )
            ->addForeignKey(
                $installer->getFkName(
                    'mconnect_pf_dropdowns',
                    'pf_id',
                    'mconnect_partfinder',
                    'pf_id'
                ),
                'pf_id',
                $installer->getTable('mconnect_partfinder'),
                'pf_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )            
            ->setComment('Mconnect Part Finder Dropdowns Table');
        $installer->getConnection()->createTable($table);
		 
		
		/**
         * Create table 'mconnect_pf_filterentity'
         */
		$table = $installer->getConnection()
            ->newTable($installer->getTable('mconnect_pf_filterentity'))
            ->addColumn(
                'entity_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Filter Entity ID'
            )
            ->addColumn(
                'pf_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Part Finder ID'
            )            
            ->addColumn(
                'sku',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Product SKU'
            )            
            ->addForeignKey(
                $installer->getFkName(
                    'mconnect_pf_filterentity',
                    'pf_id',
                    'mconnect_partfinder',
                    'pf_id'
                ),
                'pf_id',
                $installer->getTable('mconnect_partfinder'),
                'pf_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )
            ->setComment('Mconnect Part Finder Filter Entity Table');
        $installer->getConnection()->createTable($table);
		
		
		/**
         * Create table 'mconnect_pf_filter'
         */
		
		$table = $installer->getConnection()
            ->newTable($installer->getTable('mconnect_pf_filter'))
            ->addColumn(
                'pff_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Filter ID'
            )
			->addColumn(
                'entity_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Entity ID'
            )
            ->addColumn(
                'dw_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Dropdown ID'
            )
            ->addColumn(
                'value',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [],
                'Filter Value'
            )                      
            ->addForeignKey(
                $installer->getFkName(
                    'mconnect_pf_filter',
                    'dw_id',
                    'mconnect_pf_dropdowns',
                    'dw_id'
                ),
                'dw_id',
                $installer->getTable('mconnect_pf_dropdowns'),
                'dw_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )
			->addForeignKey(
                $installer->getFkName(
                    'mconnect_pf_filter',
                    'entity_id',
                    'mconnect_pf_filterentity',
                    'entity_id'
                ),
                'entity_id',
                $installer->getTable('mconnect_pf_filterentity'),
                'entity_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
            )
            ->setComment('Mconnect Part Finder Filter Table');
        $installer->getConnection()->createTable($table);
		 
        $installer->endSetup();
    }
}
