/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            addRecord:  'Mconnect_Partfinder/js/addRecord',
            select2:  'Mconnect_Partfinder/js/select2'
        }
    } 
};
