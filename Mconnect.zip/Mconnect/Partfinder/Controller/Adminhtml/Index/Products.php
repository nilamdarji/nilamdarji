<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

class Products extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory
     */
    public function __construct(   
		\Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory
    ) {
        
        $this->resultLayoutFactory = $resultLayoutFactory;
		parent::__construct($context);
    }
	
	/**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Partfinder::save');
    }
	
    /**
     * @return \Magento\Framework\View\Result\Layout
     */
    public function execute()
    {
        
        $resultLayout = $this->resultLayoutFactory->create();
        $resultLayout->getLayout()->getBlock('partfinder.products')
            ->setProductsRelated($this->getRequest()->getPost('products_related', null));
        return $resultLayout;
    }
}
