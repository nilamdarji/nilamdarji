<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Mconnect\Partfinder\Model\PartfinderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var PostDataProcessor
     */
    protected $partfinderFactory;
	
	protected $fileUploaderFactory;
	
	protected $fileSystem;
	
    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     */
    public function __construct(
		Action\Context $context, 
		PartfinderFactory $partfinder, 
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploader, 
		Filesystem $fileSystem
	){
        $this->partfinderFactory = $partfinder;		
		$this->fileUploaderFactory = $fileUploader;
		$this->fileSystem = $fileSystem;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Partfinder::save');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
		$id = $this->getRequest()->getParam('pf_id');
		
		
		 /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
		
		if ($data) {
		
			if(isset($data['stores'])) {
				if(in_array('0',$data['stores'])){
					$data['store_id'] = '0';
				}
				else{
					$data['store_id'] = implode(",", $data['stores']);
				}
			   unset($data['stores']);
			}
			$data['no_of_dropdowns'] = isset($data['fields'])? count($data['fields']) : 0;
			if($data['no_of_dropdowns']){
				foreach($data['fields'] as $d_field){
					if($d_field['is_delete']){
						$data['no_of_dropdowns']--;
					}
				}
			}
			
			$model =  $this->partfinderFactory->create();		
			$model->setData($data)
				->setId($this->getRequest()->getParam('pf_id'));
			
			
			try {
				
				$model->save();
				$this->messageManager->addSuccess(__('Part Finder was successfully saved'));
				$this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
				
				if($model->getId()){
					$delete_dw = array();
					
					if(isset($data['fields'])){						
						$fields = $data['fields'];
						$pdw_id = 0;
						$i=1;
						
						foreach($fields as $dropdown){
							if($dropdown['is_delete']){
								if($dropdown['dw_id']){
									$delete_dw[] = $dropdown['dw_id'];
								}
								continue;
							}
							$dropdown['position'] = $i;							
							unset($dropdown['id']);
							if($dropdown['dw_id'] == ""){
								unset($dropdown['dw_id']);
							}
							$dropdown['pf_id'] = $model->getId();
							$dropdown['pdw_id'] = $pdw_id;
							$dw_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Dropdowns');
							$dw_model->setData($dropdown);
							if(isset($dropdown['dw_id'])){
								$dw_model->setId($dropdown['dw_id']);								
							}
							$dw_model->save();
							$pdw_id = $dw_model->getId();							
							$i++;
						}
						
						//Delete record of dropdown which are removed
						$f_dwCollection = $this->_objectManager->create('Mconnect\Partfinder\Model\ResourceModel\Dropdowns\Collection');
						$f_dwCollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
						
						foreach($f_dwCollection as $f_dropdown){
							$f_dw_id = $f_dropdown->getId();							
							if( in_array($f_dw_id, $delete_dw) ){								
								$f_dw_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Dropdowns')->load($f_dw_id);
								$f_dw_model->delete();
							}
						}						
					}
					
					if(isset($data['import'])){
						if(isset($_FILES['import_file']['name']) && $_FILES['import_file']['name'] != '') {
							$imp_data = $_FILES['import_file'];
							//-------------------------
							try {
								$uploader = $this->fileUploaderFactory->create(['fileId' => 'import_file']);
								$uploader->setAllowedExtensions(['csv']);
								$uploader->setAllowRenameFiles(true);
								$uploader->setFilesDispersion(true);
								$path = $this->fileSystem->getDirectoryRead(DirectoryList::MEDIA)
								->getAbsolutePath('partfinder');
								$result = $uploader->save($path);
								
								$csvFile = $result['path'].$result['file'];
								$file_handle = fopen($csvFile, 'r');
								$field_head = fgetcsv($file_handle);
								
								//get fields collection
								$dwCollection = $this->_objectManager->create('Mconnect\Partfinder\Model\ResourceModel\Dropdowns\Collection');
								$dwCollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);		
								$dwCollection->getSelect()->order('position ASC');
								
								$fflag = 1;
								$is_range = array();
								if(count($field_head) == (count($dwCollection)+1)){
									$i=0;
									foreach($dwCollection as $dropdown){										
										if (strcasecmp($dropdown->getDwName(), $field_head[$i++]) !== 0) {
											$fflag = 0;
											$this->messageManager->addError(__('Field name mismatch found in uploaded CSV'));
										}
										$is_range[$i] = $dropdown->getDwRange();
									}
									if (strcasecmp("sku", $field_head[$i]) !== 0) {
										$fflag = 0;
										$this->messageManager->addError(__('Not able to find SKU column in uploaded CSV'));
									}
								}else{
									$fflag = 0;
									$this->messageManager->addError(__('Please provide all fields and product SKU column in uploaded CSV'));
								}
								if($fflag){
									if(isset($data['import']['behavior'])&& $data['import']['behavior'] == 'delete'){
										//echo $data['import']['behavior']; exit;
										$entityCollection = $this->_objectManager->create('Mconnect\Partfinder\Model\ResourceModel\Filterentity\Collection');
										$entityCollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
										foreach($entityCollection as $entity){
											$entity->delete();
										}
									}
									//Save Data to DB
									$entity_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Filterentity');
									$filter_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Filter');
									while (!feof($file_handle) ) {
										$line_of_text = fgetcsv($file_handle);
										$filter_data = array();
										$j = 0;
										$sku = $line_of_text[count($dwCollection)];
										$rqueue = array();
										if(isset($sku) && $sku != ""){
											
											//-----------------------------
											$r=0;
											$range_val="";
											foreach($is_range as $_range){												
												if($_range){
													if(intval($line_of_text[$r]) != 0){
														$range_val = $line_of_text[$r];
														break;
													}
												}
												$r++;
											}
											if($range_val != "" && intval($range_val) != 0){
												$ranges = explode("-",$range_val);
												for($a=0; $a<count($ranges); $a++){
													$ranges[$a] = intval($ranges[$a]);
												}
												sort($ranges, SORT_NUMERIC);
												if(!isset($ranges[1]) || empty($ranges[1])){
													$ranges[1] = $ranges[0];
												}
												for($d=$ranges[0]; $d <= $ranges[1]; $d++){
													
													
													//----------------------------
													$nr=0;
													$nrange_val="";
													foreach($is_range as $_range){
														if($_range && $nr > $r){
															if(intval($line_of_text[$nr]) != 0){
																$nrange_val = $line_of_text[$nr];
																break;
															}
														}
														$nr++;
													}
													if($nrange_val != "" && intval($nrange_val) != 0){
														$rqueue[$r] = $d;
														$this->saveMultiRange($entity_model, $model->getId(), $sku, $dwCollection, $filter_model, $line_of_text, $nrange_val, $nr, $is_range, $rqueue);
														
														continue;
													}
													//-----------------------------
													
													
													$fentity = array();
													$fentity['pf_id']	= $model->getId();
													$fentity['sku']		= $sku;
													$entity_model->setData($fentity);
													$entity_model->save();
													$entity_id = $entity_model->getId();
													$m=0;
													foreach($dwCollection as $ddwn){
														$filter_data['entity_id'] = $entity_id;
														$filter_data['dw_id'] = $ddwn->getId();
														if($m == $r){
															$filter_data['value'] = $d;
														}else{
															$filter_data['value'] = $line_of_text[$m];
														}
														$m++;
														$filter_model->setData($filter_data);
														$filter_model->save();
													}
												}
											}else{
											
												$fentity = array();
												$fentity['pf_id']	= $model->getId();
												$fentity['sku']		= $sku;
												$entity_model->setData($fentity);
												$entity_model->save();
												$entity_id = $entity_model->getId();
												foreach($dwCollection as $ddwn){
													$filter_data['entity_id'] = $entity_id;
													$filter_data['dw_id'] = $ddwn->getId();
													$filter_data['value'] = $line_of_text[$j];
													$j++;
													$filter_model->setData($filter_data);
													$filter_model->save();
												}												
											}
										}
									}
								}
								
								fclose($file_handle);
								
							} catch (Exception $e) {
								if ($this->getRequest()->getParam('back')) {									
									return $resultRedirect->setPath('*/*/edit', ['pf_id' => $model->getId(), '_current' => true]);
								}
								$this->_redirect('*/*/');
								return;
							}
							//------------------------------
						}						
					}
				}
				if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['pf_id' => $model->getId(), '_current' => true]);
                }
				$this->_redirect('*/*/');
				return;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the page.'));
            }
			 $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['pf_id' => $this->getRequest()->getParam('pf_id')]);
        }
	    
        return $resultRedirect->setPath('*/*/');
    }
	
	//public function saveMultiRange($dwCollection, $filter_model, $line_of_text, $range_val, $nr){
	private function saveMultiRange($entity_model, $pf_id, $sku, $dwCollection, $filter_model, $line_of_text, $range_val, $r, $is_range, $rqueue){
		$ranges = explode("-",$range_val);
		for($a=0; $a<count($ranges); $a++){
			$ranges[$a] = intval($ranges[$a]);
		}
		sort($ranges, SORT_NUMERIC);
		if(!isset($ranges[1]) || empty($ranges[1])){
			$ranges[1] = $ranges[0];
		}
		for($d=$ranges[0]; $d <= $ranges[1]; $d++){
			
			
			//----------------------------
			$nr=0;
			$nrange_val="";
			foreach($is_range as $_range){
				if($_range && $nr > $r){
					if(intval($line_of_text[$nr]) != 0){
						$nrange_val = $line_of_text[$nr];
						break;
					}
				}
				$nr++;
			}
			if($nrange_val != "" && intval($nrange_val) != 0){
				$rqueue[$nr] = $d;
				$this->saveMultiRange($entity_model, $pf_id, $sku, $dwCollection, $filter_model, $line_of_text, $nrange_val, $nr, $is_range, $rqueue);
				
				continue;
			}
			//-----------------------------
			
			
			$fentity = array();
			$fentity['pf_id']	= $pf_id;
			$fentity['sku']		= $sku;
			$entity_model->setData($fentity);
			$entity_model->save();
			$entity_id = $entity_model->getId();
			$m=0;
			foreach($dwCollection as $ddwn){
				$filter_data['entity_id'] = $entity_id;
				$filter_data['dw_id'] = $ddwn->getId();
				if($m == $r){
					$filter_data['value'] = $d;
					
				}else{
					if($m < $r && $is_range[$m+1] != 0){
						$filter_data['value'] = $rqueue[$m];
					}else{						
						$filter_data['value'] = $line_of_text[$m];
					}
				}
				$m++;
				$filter_model->setData($filter_data);
				$filter_model->save();
			}
		}
	}
}
