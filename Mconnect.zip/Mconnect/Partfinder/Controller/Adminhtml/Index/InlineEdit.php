<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Mconnect\Partfinder\Model\PartfinderFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class InlineEdit extends \Magento\Backend\App\Action
{
   
    protected $jsonFactory;

	protected $partfinderFactory;
    
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
		PartfinderFactory $partfinder
    ) {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
		$this->partfinderFactory = $partfinder;
    }

    
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

        $postItems = $this->getRequest()->getParam('items', []);
		
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $pfId) {             
            $partfinder = $this->partfinderFactory->create();
			$partfinder->load($pfId);
            try {                
				$partfinder->setData('position',$postItems[$pfId]['position']);
				$partfinder->setData('status',$postItems[$pfId]['status']);
				$partfinder->save();
                
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $messages[] = $this->getErrorWithPageId($partfinder, $e->getMessage());
                $error = true;
            } catch (\RuntimeException $e) {
                $messages[] = $this->getErrorWithPageId($partfinder, $e->getMessage());
                $error = true;
            } catch (\Exception $e) {
                $messages[] = $this->getErrorWithPageId(
                    $partfinder,
                    __('Something went wrong while saving the Part Finder.')
                );
                $error = true;
            }
        }

        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }

}
