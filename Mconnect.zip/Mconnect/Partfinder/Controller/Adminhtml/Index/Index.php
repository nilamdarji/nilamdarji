<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
/**
 * Reviews admin controller
 */
class Index extends \Magento\Backend\App\Action
{
	
	 protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Partfinder::index');
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Mconnect_Partfinder::partfinder');
        $resultPage->addBreadcrumb(__('Part Finder'), __('Part Finder'));
        $resultPage->addBreadcrumb(__('Manage Part Finders'), __('Manage Part Finder'));
        $resultPage->getConfig()->getTitle()->prepend(__('Part Finders'));

        return $resultPage;
    }
}
