<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class Render
 */
class Exportcsv extends \Magento\Backend\App\Action
{
    /**
     * @var FileFactory
     */
    protected $fileFactory;

	/**
     * @var MetadataProvider
     */
    protected $metadataProvider;
	
	protected $partfinderFactory;
	protected $_dropdownFactory;
	protected $_entityFactory;
	protected $_filterFactory;
	
    /**
     * @param Context $context
     * @param ConvertToCsv $converter
     * @param FileFactory $fileFactory
     */
    public function __construct(
        Context $context,
        FileFactory $fileFactory,		
		\Mconnect\Partfinder\Model\ResourceModel\Dropdowns\CollectionFactory $dropdownFactory,
		\Mconnect\Partfinder\Model\ResourceModel\Filterentity\CollectionFactory $entityFactory,
		\Mconnect\Partfinder\Model\ResourceModel\Filter\CollectionFactory $filterFactory
    ) {
        $this->fileFactory = $fileFactory;
		$this->_dropdownFactory = $dropdownFactory;
		$this->_entityFactory = $entityFactory;
		$this->_filterFactory = $filterFactory;		
		parent::__construct($context);
    }

    /**
     * Export data provider to CSV
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
		//============== :: Collection and Data ============== [START]
		$pf_id = $this->getRequest()->getParam('pf_id');
		$sample = $this->getRequest()->getParam('sample');
        
		$dwcollection = $this->_dropdownFactory->create();
		$dwcollection->addFieldToFilter('pf_id',['eq' => $pf_id]);
		$dwcollection->getSelect()->order('position ASC');
		
		if($sample == 0){
			$collection = $this->_entityFactory->create();
			$collection->addFieldToFilter('pf_id',['eq' => $pf_id]);
		}
		
		$h_data = array();
		
		if($sample == 0){
			$h_data['pf_id'] = __('Part Finder');
		}
		
		foreach($dwcollection as $dropdown){
			$dw_name = $dropdown->getDwName();
			$dw_id = $dropdown->getDwId();
			
			$h_data['dw'.$dw_id] = $dw_name;
			
			if($sample == 0){
				$dw = 'dw'.$dw_id;
				$collection->getSelect()->joinLeft(
					[$dw => 'mconnect_pf_filter'],
					"main_table.entity_id = ".$dw.".entity_id AND ".$dw.".dw_id = ".$dw_id,
					[$dw.'.value as dw'.$dw_id]
				);
			}
		}
		$h_data['sku'] = __('SKU');
		
		//============== :: Collection and Data ============== [END]
		/** start csv content and set template */
		$headers = new \Magento\Framework\DataObject($h_data);
		
		$template = '';
		foreach(array_keys($h_data) as $code){
			$template .= '"{{'.$code.'}}",';
		}
		$template = substr($template,0,-1);
		
        $content = $headers->toString($template);
		
        $content .= "\n";

		if($sample == 0){
			while ($filter = $collection->fetchItem()) {            
				$content .= $filter->toString($template) . "\n";
			}
		}
		$file_name = 'partfinder_'.$pf_id.'_sample.csv';
		if($sample == 0){
			$file_name = 'partfinder_'.$pf_id.'_options.csv';
		}
		
        return $this->fileFactory->create($file_name, $content, DirectoryList::VAR_DIR);
    }	
}
