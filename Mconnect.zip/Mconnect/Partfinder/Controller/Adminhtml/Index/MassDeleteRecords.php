<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Mconnect\Partfinder\Model\ResourceModel\Partfinder\CollectionFactory;
use Magento\Ui\Component\MassAction\Filter;

/**
 * Class MassDelete
 */
class MassDeleteRecords extends \Magento\Backend\App\Action
{
     protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	//protected $partfinderFactory;
	protected $_entityFactory;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		Filter $filter,
		//CollectionFactory $partfinder
		\Mconnect\Partfinder\Model\ResourceModel\Filterentity\CollectionFactory $entityFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		//$this->partfinderFactory = $partfinder;
		$this->_entityFactory = $entityFactory;
		$this->filter = $filter;
        parent::__construct($context);
    }


    /**
     * Execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
		$pf_array = $this->getRequest()->getParams('pf_id');		
		$pf_id = $this->getRequest()->getParam('pf_id');
		
		$deleteIds = $this->getRequest()->getParams('entity_id');
				
		$collection = $this->_entityFactory->create();
		$collection->addFieldToFilter('entity_id', array('in' => $deleteIds));		
		
		$count = 0;
        foreach ($collection as $filterentilty) {
			$filterentilty->delete();
			$count++;
        }
		

        $this->messageManager->addSuccess(__('A total of %1 record(s) have been deleted.', $count));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/edit', ['pf_id' => $pf_id, 'back' => 'edit', 'active_tab' => 'products']);
    }
}
