<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Mconnect\Partfinder\Model\PartfinderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class Saverecord extends \Magento\Backend\App\Action
{
    /**
     * @var PostDataProcessor
     */
    protected $partfinderFactory;
	
	protected $fileUploaderFactory;
	
	protected $fileSystem;
	
    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     */
    public function __construct(
		Action\Context $context, 
		PartfinderFactory $partfinder, 
		\Magento\MediaStorage\Model\File\UploaderFactory $fileUploader, 
		Filesystem $fileSystem
	){
        $this->partfinderFactory = $partfinder;		
		$this->fileUploaderFactory = $fileUploader;
		$this->fileSystem = $fileSystem;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Partfinder::save');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		echo "<script>
				(function ($) {
					$('#create_new_attribute').modal('closeModal');
					parent.pf_products_gridJsObject.resetFilter();
				})(window.parent.jQuery);
			</script>";
			
		
		
        $data = $this->getRequest()->getPostValue();
		$pf_id = $data['pf_id'];
		$sku = $data['sku'];
		$dw_data = array();
		foreach($data as $key => $value){
			if(substr($key, 0, 2) == 'dw'){
				$dw_id = substr($key, 2);
				if( ctype_digit($dw_id) && !empty($dw_id)){
					$dw_data[$dw_id] = $value;
				}
			}
		}
		
		if($pf_id != "" && $sku != ""){
			try {
				$entity_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Filterentity');
				$filter_model = $this->_objectManager->create('Mconnect\Partfinder\Model\Filter');
				
				$fentity = array();
				$fentity['pf_id']	= $pf_id;
				$fentity['sku']		= $sku;
				$entity_model->setData($fentity);
				$entity_model->save();
				$entity_id = $entity_model->getId();
				
				foreach($dw_data as $key => $value){
					$filter_data = array();
					
					$filter_data['entity_id'] = $entity_id;
					$filter_data['dw_id'] = $key;
					$filter_data['value'] = $value;
					
					$filter_model->setData($filter_data);
					$filter_model->save();				
				}
				$this->messageManager->addSuccess(__('Option Values added successfully'));
			} catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __($e->getMessage().'Something went wrong while saving the page.'));
            }
		}else{
			$this->messageManager->addError(__('Not able to save Option Values. Please check values and try again.'));
		}
    }	
}
