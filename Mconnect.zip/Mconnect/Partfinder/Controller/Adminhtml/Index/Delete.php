<?php
namespace Mconnect\Partfinder\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Mconnect\Partfinder\Model\PartfinderFactory;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	 protected $partfinderFactory;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		 PartfinderFactory $partfinder
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		$this->partfinderFactory = $partfinder;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Mconnect_Partfinder::save');
    }

    /**
     * Init actions
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        // load layout, set active menu and breadcrumbs
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Mconnect_Partfinder::Partfinder')
            ->addBreadcrumb(__('Partfinder'), __('Partfinder'))
            ->addBreadcrumb(__('Manage Partfinders'), __('Manage Partfinders'));
        return $resultPage;
    }

    /**
     *
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    { 
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('pf_id');
        $model = $this->partfinderFactory->create();

         $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            $title = "";
            try {
               
               
                $model->load($id);
                $title = $model->getId();
                $model->delete();
                // display success message
                $this->messageManager->addSuccess(__('The Part Finder has been deleted.'));
                // go to grid
                $this->_eventManager->dispatch(
                    'adminhtml_partfinder_on_delete',
                    ['title' => $title, 'status' => 'success']
                );
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                
                // display error message
                $this->messageManager->addError($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['pf_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addError(__('We can\'t find a Part Finder to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}
