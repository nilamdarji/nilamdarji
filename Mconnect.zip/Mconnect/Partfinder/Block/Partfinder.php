<?php
namespace Mconnect\Partfinder\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\Registry;

class Partfinder extends Template
{
	protected $scopeConfigObject;
	protected $_token;
	
	/**
	 * @var Registry
	 */
	private $registry;
	protected $jsonEncoder;
	
	private $_partfinder = null;	
	private $pf_id;

	protected $_dropdownFactory;
	protected $_entityFactory;

    public function __construct(
		Template\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Json\EncoderFactory $jsonEncoder,
		\Mconnect\Partfinder\Model\ResourceModel\Dropdowns\CollectionFactory $dropdownFactory,
		\Mconnect\Partfinder\Model\ResourceModel\Filterentity\CollectionFactory $entityFactory,
		array $data = [])
    {
        parent::__construct($context, $data);
		
		$this->scopeConfigObject = $context->getScopeConfig();
		$this->registry = $registry;
		$this->jsonEncoder = $jsonEncoder;
		$this->_dropdownFactory = $dropdownFactory;
		$this->_entityFactory = $entityFactory;
        $this->_isScopePrivate = true;
        $this->_token = rand();
    }
	
	public function getEnablePartfinder(){
		return	$this->scopeConfigObject->getValue('mconnect_partfinder/general/active');	
	}
	
	public function getStoreConfigValues($inputData){	
		return	$this->scopeConfigObject->getValue($inputData);	
	}
	
	public function loadPartfinder(){
		if($this->_partfinder == null && $this->pf_id){
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$model = $objectManager->create('Mconnect\Partfinder\Model\Partfinder');
			$model->load($this->pf_id);
			
			if($model->getStatus()){
				$this->_partfinder = $model;
			}
		}
	}
	public function categoryHasPartfinder(){
		$category = $this->registry->registry('current_category');
		if(!empty($category)){
			if(!empty($category->getPartfinderId())){
				$this->pf_id = $category->getPartfinderId();
				$this->loadPartfinder();
			}
		}
		return ( !empty($category) && !empty($category->getPartfinderId()) && $this->_partfinder);
	}
	
	public function getPartfinderTitle(){
		return $this->_partfinder->getPfName();
	}
	
	public function getDropdowns(){
		$dwCollection = $this->_dropdownFactory->create();
		$dwCollection->addFieldToFilter('pf_id',['eq' => $this->pf_id]);
		$dwCollection->getSelect()->order('position ASC');
		return $dwCollection;
	}
	
	public function getPartfinderPosition(){
		return $this->_partfinder->getPosition();
	}
	
	public function getJsData(){
		$random = $this->_token;
		$dwcollection = $this->_dropdownFactory->create();
		$dwcollection->addFieldToFilter('pf_id',['eq' => $this->pf_id]);
		//$dwcollection->getSelect()->order('position ASC');
		
		$collection = $this->_entityFactory->create();
		$collection->addFieldToFilter('pf_id',['eq' => $this->pf_id]);
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$resourceConnection = $objectManager->create('Magento\Framework\App\ResourceConnection');
		$mconnect_pf_filter = $resourceConnection->getTableName('mconnect_pf_filter');

		foreach($dwcollection as $dropdown){			
			$dw_id = $dropdown->getDwId();
			$dw = 'dw'.$dw_id;
			$collection->getSelect()->joinLeft(
				[$dw => $mconnect_pf_filter],
				"main_table.entity_id = ".$dw.".entity_id AND ".$dw.".dw_id = ".$dw_id,
				[$dw.'.value as dw'.$dw_id.'_'.$random]
			);
		}
		
		$data = array();
		foreach($collection as $entity){			
			$data[] = $entity->getData();
		}
		
		$result = $this->jsonEncoder->create();

		return $result->encode($collection->getData());
		
		//return $collection->getJsonData();
	}
	
	public function getPartfinderId(){
		return $this->pf_id;
	}
	
	public function cmsHasPartfinder(){	
		$moduleName = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        $action     = $this->getRequest()->getActionName();
        
		$searchpath = $moduleName."_".$controller."_".$action;
		if($searchpath == "partfinder_search_result"){			
			$this->pf_id = $this->getRequest()->getParam('pf_id');
			$this->loadPartfinder();	
			return ( !empty($this->pf_id) && $this->_partfinder );
		}else if($this->getPfId()){
			$this->pf_id = $this->getPfId();
			$this->loadPartfinder();			
		}
		return ( !empty($this->getPfId()) && $this->_partfinder );
	}
	
	public function getToken(){
		return $this->_token;
	}
}
