<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab;

use Magento\Backend\Block\Widget;

class Fields extends Widget
{
    /**
     * @var string
     */
    protected $_template = 'Mconnect_Partfinder::partfinder/edit/tab/options.phtml';

    /**
     * @return Widget
     */
    protected function _prepareLayout()
    {
        $this->addChild(
            'add_button',
            'Magento\Backend\Block\Widget\Button',
            ['label' => __('Add New Field'), 'class' => 'add', 'id' => 'add_new_defined_option']
        );
        
        $this->addChild('options_box', 'Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab\Fields\Option');

        return parent::_prepareLayout();
    }

    /**
     * @return string
     */
    public function getAddButtonHtml()
    {
        return $this->getChildHtml('add_button');
    }

    /**
     * @return string
     */
    public function getOptionsBoxHtml()
    {
        return $this->getChildHtml('options_box');
    }
}
