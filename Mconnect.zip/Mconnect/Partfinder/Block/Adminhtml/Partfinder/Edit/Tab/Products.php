<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab;

use Magento\Backend\Block\Widget\Grid\Column;
use Magento\Backend\Block\Widget\Grid\Extended;
use Mconnect\Partfinder\Model\PartfinderFactory;

class Products extends Extended
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

	protected $partfinderFactory;
	protected $_dropdownFactory;
	protected $_entityFactory;
	protected $_filterFactory;
		
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper     
     * @param \Magento\Framework\Registry $coreRegistry
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Framework\Registry $coreRegistry,
		PartfinderFactory $partfinder,
		\Mconnect\Partfinder\Model\ResourceModel\Dropdowns\CollectionFactory $dropdownFactory,
		\Mconnect\Partfinder\Model\ResourceModel\Filterentity\CollectionFactory $entityFactory,
		\Mconnect\Partfinder\Model\ResourceModel\Filter\CollectionFactory $filterFactory,
        array $data = []
    ) {
        $this->_coreRegistry = $coreRegistry;  
		$this->partfinderFactory = $partfinder;		
		$this->_dropdownFactory = $dropdownFactory;
		$this->_entityFactory = $entityFactory;
		$this->_filterFactory = $filterFactory;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * Set grid params
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('pf_products_grid');
        $this->setDefaultSort('entity_id');
        $this->setUseAjax(true);
        
        if (!$this->_isAllowedAction('Mconnect_Partfinder::save')) {
            $this->setFilterVisibility(false);
        }
    }

    /**
     * Add filter
     *
     * @param Column $column
     * @return $this
     */
    protected function _addColumnFilterToCollection($column)
    {
        // Set custom filter for dropdows
        if (substr($column->getId(), 0, 2) == 'dw') {
            $alias = $column->getId();
			$dw_id = substr($column->getId(), 2);
            if ($column->getFilter()->getValue()) {				
                $this->getCollection()->addFieldToFilter($alias.'.dw_id', ['eq' => $dw_id]);
                $this->getCollection()->addFieldToFilter($alias.'.value', ['like' => '%'.$column->getFilter()->getValue().'%']);
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;
    }

    /**
     * Prepare collection
     *
     * @return Extended
     */
    protected function _prepareCollection()
    {		
		$id = $this->getRequest()->getParam('pf_id');
        $model = $this->partfinderFactory->create();
		if ($id) {
            $model->load($id);
		}
		$dwcollection = $this->_dropdownFactory->create();
		$dwcollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
		$dwcollection->getSelect()->order('position ASC');
		
		$collection = $this->_entityFactory->create();
		$collection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$resourceConnection = $objectManager->create('Magento\Framework\App\ResourceConnection');
		$mconnect_pf_filter = $resourceConnection->getTableName('mconnect_pf_filter');

		foreach($dwcollection as $dropdown){			
			$dw_id = $dropdown->getDwId();
			$dw = 'dw'.$dw_id;
			$collection->getSelect()->joinLeft(
				[$dw => $mconnect_pf_filter],
				"main_table.entity_id = ".$dw.".entity_id AND ".$dw.".dw_id = ".$dw_id,
				[$dw.'.value as dw'.$dw_id]
			);
		}
		
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
	
    /**
     * Add columns to grid
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        /* $this->addColumn(
            'entity_id',
            [
                'header' => __('ID'),
                'sortable' => true,
                'index' => 'entity_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        ); */

		$id = $this->getRequest()->getParam('pf_id');
        $model = $this->partfinderFactory->create();
		if ($id) {
            $model->load($id);
		}
		
		$collection = $this->_dropdownFactory->create();
		$collection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
		$collection->getSelect()->order('position ASC');
		
		foreach($collection as $dropdown){			
			$this->addColumn(
				'dw'.$dropdown->getID(),
				[
					'header' => __(ucwords($dropdown->getDwName())),
					'index' => 'dw'.$dropdown->getID(),
					'header_css_class' => 'col-'.$dropdown->getID(),
					'column_css_class' => 'col-'.$dropdown->getID()
				]
			);
		}
		
		$this->addColumn(
            'sku',
            [
                'header' => __('SKU'),
                'index' => 'sku',
                'header_css_class' => 'col-sku',
                'column_css_class' => 'col-sku'
            ]
        );

        return parent::_prepareColumns();
    }

    /**
     * Rerieve grid URL
     *
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getData(
            'grid_url'
        ) ? $this->getData(
            'grid_url'
        ) : $this->getUrl(
            'partfinder/*/products',
            ['_current' => true]
        );
    }
	
	protected function _prepareLayout()
    { 
		return parent::_prepareLayout();
	}
	
	public function getAddrecordButtonHtml()
    {
        /** @var \Magento\Backend\Block\Widget\Button $attributeCreate */
        $attributeCreate = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        );
        $attributeCreate->setDataAttribute(
            [
                'mage-init' => [
                    'Mconnect_Partfinder/js/addRecord' => [
                        'url' => $this->getUrl("partfinder/*/addrecord", ["_current" => true]),
                    ],
                ],
            ]
        )->setType(
            'button'
        )->setLabel(
            __('Add New Record')
        )->setClass(
			'action-secondary'
		);
        return $attributeCreate->toHtml();
    }
	
	public function isConfigurableProduct(){
		return true;
	}
}
