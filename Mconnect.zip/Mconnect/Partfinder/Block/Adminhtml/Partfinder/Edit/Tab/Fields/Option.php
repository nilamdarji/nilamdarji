<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

// @codingStandardsIgnoreFile

/**
 * Customers defined options
 */
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab\Fields;

use Magento\Backend\Block\Widget;

class Option extends Widget
{
	
	protected $_dropdownFactory;
	
    
    /**
     * @var \Magento\Framework\DataObject[]
     */
    protected $_values;

    /**
     * @var int
     */
    protected $_itemCount = 1;

    /**
     * @var string
     */
    protected $_template = 'partfinder/edit/tab/fields/option.phtml';

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
    
    /**
     * @param \Magento\Backend\Block\Template\Context $context          
     * @param \Magento\Framework\Registry $registry     
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,        
		\Mconnect\Partfinder\Model\ResourceModel\Dropdowns\CollectionFactory $dropdownFactory,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
		$this->_dropdownFactory = $dropdownFactory;
        parent::__construct($context, $data);
    }

    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();

        $this->setCanReadPrice(true);
        $this->setCanEditPrice(true);
    }

    /**
     * @return int
     */
    public function getItemCount()
    {
        return $this->_itemCount;
    }

    /**
     * @param int $itemCount
     * @return $this
     */
    public function setItemCount($itemCount)
    {
        $this->_itemCount = max($this->_itemCount, $itemCount);
        return $this;
    }

    /**
     * Retrieve options field name prefix
     *
     * @return string
     */
    public function getFieldName()
    {
        return 'fields';
    }

    /**
     * Retrieve options field id prefix
     *
     * @return string
     */
    public function getFieldId()
    {
        return 'product_option';
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {        
        return parent::_prepareLayout();
    }

    /**
     * @return mixed
     */
    public function getAddButtonId()
    {
        $buttonId = $this->getLayout()->getBlock('admin.product.options')->getChildBlock('add_button')->getId();
        return $buttonId;
    }

    /**
     * @return mixed
     */
    public function getSortSelectHtml()
    {
        $select = $this->getLayout()->createBlock(
            'Magento\Framework\View\Element\Html\Select'
        )->setData(
            [
                'id' => $this->getFieldId() . '_<%- data.id %>_dw_sort',
                'class' => 'select select-product-option-type required-option-select',
            ]
        )->setName(
            $this->getFieldName() . '[<%- data.id %>][dw_sort]'
        )->setOptions(            
			array(
				''=>'Please Select..',
				'a_asc' => 'Alphabetically in ascending order',
				'a_desc' => 'Alphabetically in descending order', 
				'n_asc' => 'Numerically in ascending order',
				'n_desc' => 'Numerically in descending order'
			)
        );

        return $select->getHtml();
    }

    /**
     * @return mixed
     */
    public function getRangeSelectHtml()
    {
        $select = $this->getLayout()->createBlock(
            'Magento\Framework\View\Element\Html\Select'
        )->setData(
            ['id' => $this->getFieldId() . '_<%- data.id %>_dw_range', 'class' => 'select']
        )->setName(
            $this->getFieldName() . '[<%- data.id %>][dw_range]'
        )->setOptions(
            
			array(
				'0'=>'No',
				'1' => 'Yes')
        );

        return $select->getHtml();
    }

    /**
     * @return \Magento\Framework\DataObject[]
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getOptionValues()
    {
		$model = $this->_coreRegistry->registry('partfinder');
		
		$dwCollection = $this->_dropdownFactory->create();
		$dwCollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
		
		$dwCollection->getSelect()->order('position ASC');
		
		$values = [];
		foreach ($dwCollection as $dropdown) {
                
                $this->setItemCount($dropdown->getID());

                $value = [];

                $value['id'] = $dropdown->getID();
                $value['item_count'] = $this->getItemCount();
                $value['dw_id'] = $dropdown->getID();
                $value['dw_name'] = $dropdown->getDwName();
                $value['dw_sort'] = $dropdown->getDwSort();
                $value['dw_range'] = $dropdown->getDwRange();
                $value['pdw_id'] = $dropdown->getPdwId();
                
				$values[] = new \Magento\Framework\DataObject($value);
		}
		$this->_values = $values;
		
		return $this->_values;
    }
}
