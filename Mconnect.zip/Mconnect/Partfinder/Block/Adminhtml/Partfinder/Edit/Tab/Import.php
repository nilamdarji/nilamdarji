<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab;

class Import extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {        
        $model = $this->_coreRegistry->registry('partfinder');

        /*
         * Checking if user have permissions to save information
         */
        if ($this->_isAllowedAction('Mconnect_Partfinder::save')) {
            $isElementDisabled = false;
        } else {
            $isElementDisabled = true;
        }

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('partfinder_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Import Data')]);

        $fieldset->addField(
            'import[behavior]',
            'select',
            [
                'name' => 'import[behavior]',
                'label' => __('Import Behavior'),
                'title' => __('Import Behavior'),
                'disabled' => $isElementDisabled,				
				'values' => array('append' => 'Append Data', 'delete' => 'Delete Existing Data')
            ]
        );
		
		$params = array();
		$params['pf_id'] = $model->getId();
		$params['sample'] = 1;
		$fieldset->addField(
            'import_file',
            'file',
            [
                'name' => 'import_file',
                'label' => __('Select CSV File'),
                'title' => __('Select CSV File'),
				'note' => __('dropdown1, dropdown2, ..., SKU. <br>Separate range values by `-` Eg. 2010-2015
				
						<br><a href="'.$this->getUrl('*/*/exportcsv', $params).'">Download sample csv file for import</a>'),
                'class' => 'input-file'
            ]
        );
        
		$params['sample'] = 0;
        $fieldset->addField(
            'import[export_data]',
            'button',
            [
                'label' => __('Export Data'),
                'title' => __('Export Data'),
                'name' => 'import[export_data]',
				'value' => 'Export',
                'onclick' => 'setLocation(\''.$this->getUrl('*/*/exportcsv', $params) .'\');',
                'disabled' => $isElementDisabled
            ]
        );
		
        if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }

        $this->_eventManager->dispatch('adminhtml_partfinder_edit_tab_main_prepare_form', ['form' => $form]);
        
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Part Finder Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Part Finder Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
