<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit;
/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('partfinder_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Part Finder Information'));
    }
	
	protected function _beforeToHtml()
    {
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$model = $objectManager->get('Magento\Framework\Registry')->registry('partfinder');
		
        $this->addTab(
            'main',
            [
                'label' => __('General'),
                'title' => __('General'),
                'content' => $this->getLayout()->createBlock(
                    'Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab\Main'
                )->toHtml(),
                'active' => true
            ]
        );
		
		$this->addTab(
			'fields',
			[
				'label' => __('Fields'),
				'title' => __('Fields'),
				'content' => $this->getLayout()->createBlock(
					'Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab\Fields'
				)->toHtml()
			]
		);
			
		$this->addTab(
			'import',
			[
				'label' => __('Import'),
				'title' => __('Import'),
				'content' => $this->getLayout()->createBlock(
					'Mconnect\Partfinder\Block\Adminhtml\Partfinder\Edit\Tab\Import'
				)->toHtml()
			]
		);
		$this->addTab(
			'products',
			[
				'label' => __('Products'),
				'title' => __('Products'),
				'url' => $this->getUrl('partfinder/*/products', ['_current' => true]),
				'class' => 'ajax'					
			]
		);
		
        return parent::_beforeToHtml();
    }
}
