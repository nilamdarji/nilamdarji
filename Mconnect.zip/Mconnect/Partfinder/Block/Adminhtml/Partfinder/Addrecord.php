<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder;

class Addrecord extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
    
    protected function _construct()
    {
        $this->_objectId = 'pf_id';
        $this->_blockGroup = 'Mconnect_Partfinder';
        $this->_controller = 'adminhtml_Partfinder';

        parent::_construct();

        if ($this->_isAllowedAction('Mconnect_Partfinder::save')) {
            $this->buttonList->update('save', 'label', __('Save Option Values'));
        } else {
            $this->buttonList->remove('save');
        }
		
		$this->buttonList->remove('saveandcontinue');
		$this->buttonList->remove('delete');
		$this->buttonList->remove('back');
    }

    /**
     * Retrieve text for header element depending on loaded page
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('partfinder')->getId()) {
            return __("Edit Part Finder '%1'", $this->escapeHtml($this->_coreRegistry->registry('partfinder')->getPfName()));
        } else {
            return __('New Part Finder');
        }
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * Getter of url for "Save and Continue" button
     * tab_id will be replaced by desired by JS later
     *
     * @return string
     */
    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl('partfinder/*/addrecord', ['_current' => true, 'back' => 'edit', 'active_tab' => '{{tab_id}}']);
    }
	
	public function getSaveUrl(){
		return $this->getUrl('partfinder/*/saverecord', []);
	}

}
