<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder\Addrecord;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
	/**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_dropdownFactory;
	
	/**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
		\Mconnect\Partfinder\Model\ResourceModel\Dropdowns\CollectionFactory $dropdownFactory,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_dropdownFactory = $dropdownFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

	
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
		$model = $this->_coreRegistry->registry('partfinder');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->_getSaveAndContinueUrl(), 'method' => 'post', 'enctype' => 'multipart/form-data']]
        );
        $form->setUseContainer(true);
		
		/*
         * Checking if user have permissions to save information
         */
        if ($this->_isAllowedAction('Mconnect_Partfinder::save')) {
            $isElementDisabled = false;
        } else {
            $isElementDisabled = true;
        }
		
		$form->setHtmlIdPrefix('partfinder_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Option Values')]);

        if ($model->getId()) {
            $fieldset->addField('pf_id', 'hidden', ['name' => 'pf_id', 'value' => $model->getId()]);
        }

		$dwCollection = $this->_dropdownFactory->create();
		$dwCollection->addFieldToFilter('pf_id',['eq' => $model->getId()]);
		
		$dwCollection->getSelect()->order('pdw_id ASC');
		
		
		foreach($dwCollection as $dropdown){
			
			$dw_id = "dw".$dropdown->getID();
			$dw_name = $dropdown->getDwName();
			
			$range_text = '';
			if($dropdown->getDwRange()){
				$range_text = 'Separate range values by `-` Eg. 2010-2015';
			}
			$fieldset->addField(
				$dw_id,
				'text',
				[
					'name' => $dw_id,
					'label' => ucwords($dw_name),
					'title' => ucwords($dw_name),
					'required' => true,
					'note' => $range_text,
					'disabled' => $isElementDisabled
				]
			);
		}
		
		//-----------------------------------------------
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();		
		$productCollection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');		
		$productCollection->load();
		$skus = $productCollection->getColumnValues('sku');	
		$sku_options = array();
		
		$sku_options[''] = 'Please Select SKU..';
		foreach($skus as $sku){
			$sku_options[$sku] = $sku;
		}
		
		$fieldset->addField(
			'sku',
			'select',
			[
				'name' => 'sku',
				'label' => __('Sku'),
				'title' => __('Sku'),
				'required' => true,
				'disabled' => $isElementDisabled,
				'values'	=> $sku_options
			]
		);
		
		$Lastfield = $form->getElement('sku');
		$Lastfield->setAfterElementHtml(
			'<script>
				require(["jquery","select2"],function(jQuery) {  
					 jQuery(function(){

						jQuery("#partfinder_sku").select2();							
						jQuery("span[aria-labelledby=\'select2-partfinder_sku-container\']").css("border-radius","0");
						jQuery("span[aria-labelledby=\'select2-partfinder_sku-container\']").css("height","35px");
						jQuery("span[aria-labelledby=\'select2-partfinder_sku-container\']").css("padding","3px");
						jQuery(".select2-selection__arrow").css("height","35px");
						jQuery(".select2-selection__arrow").css("padding-right","30px");
						jQuery(".addafter").css("width","100%");						
					});
				});
			</script>
			<label id="partfinder_sku-error" class="mage-error" for="partfinder_sku" generated="true" style="display: none;">This is a required field.</label>
			'
        );
		//-----------------------------------------------
		
        $this->setForm($form);
        return parent::_prepareForm();
    }
	
	
	/**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
	
	/**
     * Getter of url for "Save and Continue" button
     * tab_id will be replaced by desired by JS later
     *
     * @return string
     */
    protected function _getSaveAndContinueUrl()
    {        
        return $this->getUrl('partfinder/*/saverecord', []);
    }
	
}
