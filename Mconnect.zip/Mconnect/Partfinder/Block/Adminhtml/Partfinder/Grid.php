<?php
namespace Mconnect\Partfinder\Block\Adminhtml\Partfinder;

/**
 * Adminhtml part finder grid
 */
class Grid extends \Magento\Backend\Block\Widget\Grid
{
   
}
