<?php
namespace Mconnect\Partfinder\Block\Adminhtml;

class Partfinder extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Mconnect_Partfinder';
        $this->_headerText = __('Part Finder');
        $this->_addButtonLabel = __('Create New Part Finder');
        parent::_construct();
        
		if ($this->_isAllowedAction('Mconnect_Partfinder::save')) {
            $this->buttonList->update('add', 'label', __('Create New Part Finder'));
        } else {
            $this->buttonList->remove('add');
        }
    }
	
	protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
   
}
