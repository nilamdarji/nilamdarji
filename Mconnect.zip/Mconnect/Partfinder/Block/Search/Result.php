<?php
namespace Mconnect\Partfinder\Block\Search;

use Magento\Framework\Registry;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\View\Element\Template;

class Result extends Template
{
	protected $scopeConfigObject;	
	protected $_messageManager;
	
    public function __construct(
		Template\Context $context,		
		\Magento\Framework\Message\ManagerInterface $messageManager,
		array $data = [])
    {
        parent::__construct($context, $data);
		
		$this->scopeConfigObject = $context->getScopeConfig();
        $this->_isScopePrivate = true;		
		$this->_messageManager = $messageManager;
    }
		
	public function getResultHtml(){
		//display partfinder search block
		$pf_id = $this->getRequest()->getParam('pf_id');		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$model = $objectManager->create('Mconnect\Partfinder\Model\Partfinder');
		$model->load($pf_id);		
		if(!$model->getStatus()){			
			$this->_messageManager->addError(__('This Part Finder no longer available.'));
			return;			
		}
			
		$pf_block = $this->getLayout()->createBlock(
			'Mconnect\Partfinder\Block\Partfinder',
			'cms_partfinder'
		);
		$pf_block->setTemplate('Mconnect_Partfinder::cms_partfinder.phtml');
		echo $pf_block->toHtml();
		
		// Display product list with pagination and toolbar
		$block = $this->getLayout()->createBlock(
			'Magento\Catalog\Block\Product\ListProduct',
			'product_list',
			['label' => __('Back'), 'template' => 'Magento_Catalog::product/list.phtml', 'class' => 'cancel']
		);
		$block->setTemplate('Magento_Catalog::product/list.phtml');
		
		$details_renderers = $this->getLayout()->createBlock(
			'Magento\Framework\View\Element\RendererList',
			'category.product.type.details.renderers'			
		);		
		$details_renderers_tmplt = $this->getLayout()->createBlock(
			'Magento\Framework\View\Element\Template'			
		);		
		$details_renderers->setChild('default', $details_renderers_tmplt);
		
		$configurable = $details_renderers_tmplt = $this->getLayout()->createBlock(
			'Magento\Swatches\Block\Product\Renderer\Listing\Configurable'
		);
		$configurable->setTemplate('Magento_Swatches::product/listing/renderer.phtml');
		$details_renderers->setChild('configurable', $configurable);
		
		$toolbar = $this->getLayout()->createBlock(
			'Magento\Catalog\Block\Product\ProductList\Toolbar',
			'product_list_toolbar'			
		);
		$toolbar->setTemplate('Magento_Catalog::product/list/toolbar.phtml');
		
		$pager = $this->getLayout()->createBlock(
			'Magento\Theme\Block\Html\Pager',
			'product_list_toolbar_pager'
		);
		
		$toolbar->setChild('product_list_toolbar_pager', $pager);
		
		$addto = $this->getLayout()->createBlock(
			'Magento\Catalog\Block\Product\ProductList\Item\Container',
			'category.product.addto'
		);
		
		$compare = $this->getLayout()->createBlock(
			'Magento\Catalog\Block\Product\ProductList\Item\AddTo\Compare',
			'category.product.addto.compare'
		);
		$compare->setTemplate('Magento_Catalog::product/list/addto/compare.phtml');
		
		$wishlist = $this->getLayout()->createBlock(
			'Magento\Wishlist\Block\Catalog\Product\ProductList\Item\AddTo\Wishlist',
			'category.product.addto.wishlist'
		);
		$wishlist->setTemplate('Magento_Wishlist::catalog/product/list/addto/wishlist.phtml');
		
		$addto->setChild('wishlist', $wishlist);
		$addto->setChild('compare', $compare);
		
		$block->setChild('product_list_toolbar', $toolbar);
		$block->setToolbarBlockName('product_list_toolbar');
		
		$block->setChild('addto', $addto);
		
		$block->setChild('details.renderers', $details_renderers);
		
		echo $block->toHtml();		
	}
}
