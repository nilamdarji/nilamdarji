<?php
namespace Mconnect\Partfinder\Helper;
use Magento\Framework\App\Helper\AbstractHelper;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 */
class Partfinder extends AbstractHelper 
{
 
	protected $scopeConfigObject;
	
    public function __construct(
	\Magento\Framework\App\Helper\Context $context

	){
        parent::__construct($context);
		$this->scopeConfigObject = $context->getScopeConfig();

    }
    /**
     *
     * @param Action $action
     * @param null $pageId
     * @return \Magento\Framework\View\Result\Page|bool
     */
    public function includeJs()
    {
        $enabled = $this->scopeConfigObject->getValue('mconnect_partfinder/general/active');
			if ($enabled) {
				return 'Mconnect_Partfinder::js/partfinder/jquery-1.9.1.min.js';
			} else {
				return 'Mconnect_Partfinder::js/partfinder/test.js';
			}
        
    }

    
}
