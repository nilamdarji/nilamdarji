<?php
namespace Mconnect\Partfinder\Model;
 
class Partfinder extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
	const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;
	
	const POSITION_TOP 		= 'category_top';
	const POSITION_LEFT		= 'sidebar_left';
	const POSITION_RIGHT	= 'sidebar_right';
	
	
    protected function _construct()
    { 
        $this->_init('Mconnect\Partfinder\Model\ResourceModel\Partfinder');
		
    }
	
	public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }
	
	public function getAvailablePositions()
    {
        return [self::POSITION_TOP => __('Category Top'), self::POSITION_LEFT => __('Left Sidebar'), self::POSITION_RIGHT => __('Right Sidebar')];
    }
}
 
?>