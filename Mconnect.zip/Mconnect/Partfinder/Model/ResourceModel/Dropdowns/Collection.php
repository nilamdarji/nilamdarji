<?php
namespace Mconnect\Partfinder\Model\ResourceModel\Dropdowns;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
 
   protected $_idFieldName = 'dw_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Partfinder\Model\Dropdowns', 'Mconnect\Partfinder\Model\ResourceModel\Dropdowns');
		$this->_map['fields']['dw_id'] = 'main_table.dw_id';
		$this->_map['fields']['pf_id'] = 'main_table.pf_id';
        $this->_map['fields']['store'] = 'store_table.store_id';
    }
 
   
    public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }
}