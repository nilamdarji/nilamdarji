<?php
namespace Mconnect\Partfinder\Model\ResourceModel;
 
class Dropdowns extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {       
        $this->_init('mconnect_pf_dropdowns', 'dw_id');
    }
}
?>