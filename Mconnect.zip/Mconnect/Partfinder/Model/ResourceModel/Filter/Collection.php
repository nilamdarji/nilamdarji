<?php
namespace Mconnect\Partfinder\Model\ResourceModel\Filter;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
 
   protected $_idFieldName = 'dw_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Partfinder\Model\Filter', 'Mconnect\Partfinder\Model\ResourceModel\Filter');
		$this->_map['fields']['pff_id'] = 'main_table.pff_id';
		$this->_map['fields']['dw_id'] = 'main_table.dw_id';
		$this->_map['fields']['entity_id'] = 'main_table.entity_id';
        $this->_map['fields']['store'] = 'store_table.store_id';
    }
 
   
    public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }
}