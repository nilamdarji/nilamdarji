<?php
namespace Mconnect\Partfinder\Model\ResourceModel\Filterentity;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'entity_id';
   
    protected function _construct()
    {
        $this->_init('Mconnect\Partfinder\Model\Filterentity', 'Mconnect\Partfinder\Model\ResourceModel\Filterentity');
		$this->_map['fields']['entity_id'] = 'main_table.entity_id';
		$this->_map['fields']['pf_id'] = 'main_table.pf_id';
        $this->_map['fields']['store'] = 'store_table.store_id';
    } 
}