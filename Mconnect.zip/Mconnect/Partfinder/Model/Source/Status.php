<?php
namespace Mconnect\Partfinder\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class Status implements OptionSourceInterface
{
   
    protected $partfinder;

   
    public function __construct(\Mconnect\Partfinder\Model\Partfinder $partfinder)
    {
        $this->partfinder = $partfinder;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $availableOptions = $this->partfinder->getAvailableStatuses();
        $options = [];
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }
}
